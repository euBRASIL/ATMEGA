// Ansteuerung eines HD44780 kompatiblen LCD im 4-Bit-Interfacemodus
// http://www.mikrocontroller.net/articles/AVR-GCC-Tutorial
//
// Die Pinbelegung ist �ber defines in lcd-routines.h einstellbar
 
#include <avr/io.h>
#include "config.h"
#include "lcd-routines.h"
#include "wait1000ms.h"
#include <util/delay.h>
#include <avr/pgmspace.h>

 
// sendet Ziffer an das LCD 
void lcd_ziff(unsigned char temp)
{
 lcd_data(temp + '1');
}
// sendet ein Datenbyte an das LCD
void lcd_data(unsigned char temp1)
{
 LCD_PORT |= (1<<LCD_RS);        // RS auf 1 setzen
 lcd_send(temp1);
#ifdef WIRTH_UART
 switch(temp1)
   {
    case LCD_CHAR_DIODE:
    	uart_putc('>');
    	uart_putc('|');
    	break;
    case LCD_CHAR_DIODE2:
    	uart_putc('|');
    	uart_putc('<');
    	break;
    case 225:	//�
    	uart_putc('�');
    	break;
    case 228:	//�
    	uart_putc('�');
    	break;
    case 244:	//Omega
    	break;
    default:
    	uart_putc(temp1);
   }
#endif
}
 
// sendet einen Befehl an das LCD
 
void lcd_command(unsigned char temp1)
{
	LCD_PORT &= ~(1<<LCD_RS);        // RS auf 0 setzen
	lcd_send(temp1);
#ifdef WIRTH_UART
	if((temp1 == 0x80) || (temp1 == 0xC0)) {
		uart_newline();
	}
#endif
}

//Eigentliche LCD-Zugriffs-Funktion; 4-Bit-Modus
void lcd_send(unsigned char data) {
   // oberes Nibble setzen
  LCD_PORT = (LCD_PORT & 0xF0) | ((data >> 4) & 0x0F);
  _delay_us(5);
  lcd_enable();
   // unteres Nibble setzen
  LCD_PORT = (LCD_PORT & 0xF0) | (data & 0x0F);
  _delay_us(5);
  lcd_enable();
  wait50us();
  LCD_PORT &= 0xF0;
}

// erzeugt den Enable-Puls
void lcd_enable(void)
{
   LCD_PORT |= (1<<LCD_EN1);
   wait10us();			// kurze Pause
   // Bei Problemen ggf. Pause gem�� Datenblatt des LCD Controllers verl�ngern
   // http://www.mikrocontroller.net/topic/80900
   LCD_PORT &= ~(1<<LCD_EN1);
}
 
// Initialisierung: 
// Muss ganz am Anfang des Programms aufgerufen werden.
 
void lcd_init(void)
{
	LCD_DDR = LCD_DDR | 0x0F | (1<<LCD_RS) | (1<<LCD_EN1);   // Port auf Ausgang schalten
	// muss 3mal hintereinander gesendet werden zur Initialisierung
        wait30ms();
	LCD_PORT = (LCD_PORT & 0xF0 & ~(1<<LCD_RS)) | 0x03;
	lcd_enable();

	wait5ms();
	lcd_enable();

	wait1ms();
	lcd_enable();
	wait1ms();
	LCD_PORT = (LCD_PORT & 0xF0 & ~(1<<LCD_RS)) | 0x02;
	wait1ms();
	lcd_enable();
	wait1ms();

	// 4Bit / 2 Zeilen / 5x7
	lcd_command(CMD_SetIFOptions | 0x08);

	// Display ein / Cursor aus / kein Blinken
	lcd_command(CMD_SetDisplayAndCursor | 0x04);

	// inkrement / kein Scrollen    
	lcd_command(CMD_SetEntryMode | 0x02);	
	lcd_clear();
}
 
// Sendet den Befehl zur L�schung des Displays
 
void lcd_clear(void)
{
   lcd_command(CLEAR_DISPLAY);
   wait5ms();
   uart_newline();
}


void uart_newline(void)
{
#ifdef WIRTH_UART
   uart_putc('\r');
   uart_putc('\n');
#endif
}
 
 
// Schreibt einen String auf das LCD
 
void lcd_string(char *data)
{
    while(*data) {
        lcd_data(*data);
        data++;
    }
}

//String aus PGM laden und an LCD senden
void lcd_pgm_string(const unsigned char *data)
{
	unsigned char cc;
   while(1) {
	cc = pgm_read_byte(data);
	if((cc==0) || (cc==128)) return;
	lcd_data(cc);
	data++;
   }
}


void lcd_pgm_customchar(const unsigned char *chardata)
{	
    for(uint8_t i=0;i<8;i++) {
        lcd_data(pgm_read_byte(chardata));
        chardata++;
    }
}
