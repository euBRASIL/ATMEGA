// �berarbeitet von K.-H. K�bbeler
// ReadCapacity versucht �ber die Lade-Eigenschaft den Wert eines Kondensators zu ermitteln
// Zuerst wird der LowPin auf Massepotential gelegt und der Kondensator �ber R_L entladen.
// Dann wird mit Hilfe des 16-Bit Timer 1 und dem analogen Komparator die Zeit gemessen,
// die der Kondensator mit Hilfe des �ber den R_L Widerstandes auf VCC
// geschalteten HighPin braucht, um die interne 1.3V Vergleichsspannung zu erreichen.
// danach wird der Kondensator wieder entladen.
// Wenn die Zeit zu kurz f�r eine Auswertung war, wird die Messung mit dem R_H Widerstand
// wiederholt.
// Falls die Messung erfolgreich war, werden folgende globale Variablen gesetzt:
// cval = gemessener Kapazit�tswert
// cpre = Einheit der Messwertes (0==pF, 1=nF)
// ca   = Pinnummer (0-2) des LowPins
// cb   = Pinnummer (0-2) des HighPins

unsigned long CombineBI2Long( uint8_t ovcnt, unsigned int tmpcnt); //Hilfsfunktion zur Geamtzeitbestimmung


//=================================================================
void ReadCapacity(uint8_t HighPin, uint8_t LowPin)
 { //Test auf Kondensator (auch nur auf ATMega8 m�glich)
  unsigned int tmpint;
  unsigned int adcv[4];
  uint8_t HiPinR_L, HiPinR_H;
  uint8_t LoADC;
  uint8_t ovcnt;
  uint8_t ii;

  HiPinR_L = pgm_read_byte(&PinRLtab[HighPin]);	//R_L Befehl HighPin
  HiPinR_H = HiPinR_L + HiPinR_L;	//R_H

  if(PartFound == PART_CAPACITOR)
    {
#if DebugOut == 10
     Line3();
     lcd_clear_line();
     Line3();
     lcd_ziff(LowPin);
     lcd_data('C');
     lcd_ziff(HighPin);
     lcd_data(' ');
     lcd_data('d');
     lcd_data('o');
     lcd_data('p');
     wait1000ms();
     wait1000ms();
#endif
     return;	//Schon einen Kondensator gefunden
    }
  
  EntladePins();			// Kondensator entladen
  LoADC = pgm_read_byte(&PinADCtab[LowPin]) | TXD_MSK;
  ADC_PORT = TXD_VAL;			// ADC-Port Ausg�nge auf Masse
  R_PORT = 0;
  ADC_DDR = LoADC;			//Low-Pin fest auf Masse
  R_DDR = HiPinR_L;			//HighPin �ber R_L auf Masse
  adcv[0] = ReadADC(HighPin);		//Spannung vor dem Laden
  for (ovcnt=0;ovcnt<20;ovcnt++)
    {
     ChargePin10ms(HiPinR_L,1);		//HighPin �ber R_L 10ms auf +, danach hochohmig
     adcv[2] = ReadADC(HighPin) - adcv[0]; // Spannung lesen, wurde geladen?
     if (adcv[2] > 25) break;		// bis etwa 50mF erh�ht sich die Spannung ausreichend
    }
  adcv[1] = W5msReadADC(HighPin) - adcv[0]; // und nach 5ms nochmal, h�lt Baustein die Spannung?
  wdt_reset();


#if DebugOut == 10
  Line3();
  lcd_clear_line();
  Line3();
  lcd_ziff(LowPin);
  lcd_data('C');
  lcd_ziff(HighPin);
  lcd_data(' ');
  lcd_data('U');
  lcd_data('0');
  lcd_data(':');
  lcd_string(utoa(adcv[0],outval,10));
  lcd_data(' ');
  lcd_data('U');
  lcd_data('2');
  lcd_data(':');
  lcd_string(utoa(adcv[2],outval,10));
  for(ii=0;ii<6;ii++) lcd_data(' ');
  Line4();
  lcd_data('U');
  lcd_data('1');
  lcd_data(':');
  lcd_string(utoa(adcv[1],outval,10));
  lcd_data(' ');
  wait1000ms();
  wait1000ms();
  wait1000ms();
#endif
  if (adcv[2] < 26)
    {
#if DebugOut == 10
     lcd_data('K');
     lcd_data(' ');
     wait1000ms();
#endif
     goto keinC;		// wurde nie ausreichend geladen, >50mF, Kurzschlu�
    }
  if (adcv[1] < 20)
    {
#if DebugOut == 10
     lcd_data('L');
     lcd_data(' ');
     wait1000ms();
#endif
     goto keinC;		// Bauteil h�lt Ladung keine 5ms
    }
  //Spannung ist gestiegen und h�lt Spannung
  if ((ovcnt == 0 ) && (adcv[2] > 3282)) goto messe_mit_rh;
  // Kapazit�t sch�tzungsweise > 15�F
  ChargePin10ms(HiPinR_H,0);		//HighPin �ber R_H 10ms auf -, danach hochohmig
  adcv[3] = ReadADC(HighPin) - adcv[0]; // Spannung lesen, wurde nur wenig entladen?
#if DebugOut == 10
  lcd_data('U');
  lcd_data('3');
  lcd_data(':');
  lcd_string(utoa(adcv[3],outval,10));
  lcd_data(' ');
  wait1000ms();
  wait1000ms();
#endif
  if ((adcv[3] + adcv[3]) < adcv[2])
    {
#if DebugOut == 10
     lcd_data('H');
     lcd_data(' ');
     wait1000ms();
#endif
     goto keinC; //Unplausibel, nicht mal halbe Spannung
    }
  EntladePins();			// Kondensator entladen

//=============================================================================================
// Zeitkonstanten-Bestimmung mit Analog-Komparator und Timer 1
// setup Analog Comparator
  SFIOR = (1<<ACME);			//enable Analog Comparator Multiplexer
  ACSR = (0<<ACD) | (1<<ACBG) | (1<<ACI) | (0<<ACIE) | (1<<ACIC); // nimm 1.3V als Pos Input
  ADMUX = (0<<REFS1) | (1<<REFS0) | HighPin;		// HighPin negativer Eingang
  ADCSRA = (0<<ADEN) | (0<<ADSC) | (0<<ADFR) | (1<<ADIF) | (1<<ADPS1) | (1<<ADPS0); //disable ADC
  wait50us();

  ovcnt = 0;
  ADC_DDR = 7 | (1<<TxD);		//alle Pins auf Ausgang und auf Masse
// setup Timer1
  TCCR1A = 0;			// set Counter1 to normal Mode
  TCNT1 = 0;				//set Counter to 0
  TIFR = (1<<OCF2) | (1<<TOV2) | (1<<ICF1) | (1<<OCF1A) | (1<<OCF1B) | (1<<TOV1) | (1<<TOV0);
  R_PORT = HiPinR_L;         	// HighPin �ber R_L auf Plus
  R_DDR = HiPinR_L;   		// HighPin �ber R_L auf Ausgang (Plus)
  ADC_DDR = LoADC;        		// nur LowPin auf Masse, Kondensator �ber R_L laden
  TCCR1B = (0<<ICNC1) | (0<<ICES1) | (1<<CS10); // Input Capture falling edge, Start Counter 1MHz
//******************************
  while(1)
    {  // Warten, bis Input Capture gesetzt
     ii = TIFR;			//Timer Flags lesen
     if (ii & (1<<ICF1)) break;
     if((ii & (1<<TOV1)))
       { // Timer �berlauf, 65,536 ms
        wdt_reset();
        TIFR = (1<<TOV1);		// Reset OV Flag
        ovcnt++;
        if(ovcnt == 250) break; 	//Timeout f�r Ladung, �ber 16 s
       }
    }
  TCCR1B = (0<<ICNC1) | (0<<ICES1) | (0<<CS10);  // Halte Timer an
  TIFR = (1<<ICF1);			// Reset Input Capture
  tmpint = ICR1;		// get Input Capture Counter
// mit aktuellem Counter pr�fen, ob noch ein �bertrag
// wenn TCNT1 > tmpint, kann der OV nicht nach dem Input Capture erfolgt sein,
// weil dann der Z�hler auf 0 zur�ckgesetzt w�re und den Input-Capture Wert nicht �berholt
// haben k�nnte.
   if((TCNT1 > tmpint) && (ii & (1<<TOV1)))
     { // dieser OV wurde noch nicht gez�hlt
      TIFR = (1<<TOV1);		// Reset OV Flag
      ovcnt++;
     }
  R_PORT = 0;
   cval = CombineBI2Long(ovcnt, tmpint);
   cval *= L_CAPACITY_FACTOR; 	// 253 (273)
   cval /= 50;
   cpre = 1;		// nF Ausgabe
#if DebugOut == 10
   R_DDR = 0;		// Widerstands-Port hochohmig
   Line3();
   lcd_clear_line();
   Line3();
   lcd_ziff(LowPin);
   lcd_data('c');
   lcd_ziff(HighPin);
   lcd_data(' ');
   lcd_string(ultoa(cval,outval,10));
   lcd_data('n');
   for(ii=0;ii<3;ii++) wait1000ms();
   R_DDR = HiPinR_L;		/*High-Pin �ber R_L auf Masse*/
#endif
//   if((ovcnt != 0) || (tmpint>2560)) goto markC;	
   goto markC;

// Messung kleiner Kapazit�ten 
messe_mit_rh:
  ChargePin10ms(HiPinR_L,1);		//HighPin �ber R_L 10ms auf +, danach hochohmig
  ChargePin10ms(HiPinR_L,1);		//HighPin �ber R_L 10ms auf +, danach hochohmig
  adcv[3] = ReadADC(HighPin) - adcv[0]; // Spannung lesen, wurde geladen?
#if DebugOut == 10
  lcd_data('u');
  lcd_data('3');
  lcd_data(':');
  lcd_string(utoa(adcv[3],outval,10));
  lcd_data(' ');
  wait1000ms();
  wait1000ms();
#endif
  if((adcv[3] < (adcv[2] + adcv[2]/4)) && (adcv[3] < 4155))
    {
#if DebugOut == 10
     lcd_data('W');
     lcd_data(' ');
     wait1000ms();
#endif
     goto keinC;	//Spannung ist nicht nennenswert gestiegen => Abbruch
    }
  if((NumOfDiodes > 0) && (adcv[3] > 4644) && (PartFound != PART_FET))
    {
#if DebugOut == 10
     lcd_data('D');
     lcd_data(' ');
     wait1000ms();
#endif
     goto keinC; //h�chstwahrscheinlich eine (oder mehrere) Diode(n) in Sperrrichtung,
                 //die sonst f�lschlicherweise als Kondensator erkannt wird
    }
   //Niedrige Kapazit�t  < etwa 14 �F
   EntladePins();			// Kondensator entladen
   //mit R_H erneut messen
   R_PORT = 0;		// R_DDR ist HiPinR_L
   ADC_DDR = 7 | (1<<TxD);		//alle Pins auf Ausgang
   ADC_PORT = TXD_VAL;		//alle Pins fest auf Masse
   R_DDR = HiPinR_H;   		// HighPin �ber R_H auf Ausgang
// setup Analog Comparator
   SFIOR = (1<<ACME);			//enable Analog Comparator Multiplexer
   ACSR = (0<<ACD) | (1<<ACBG) | (1<<ACI) | (0<<ACIE) | (1<<ACIC); // enable, 1.3V, no Interrupt, Connect to Timer1 
   ADMUX = (0<<REFS1) | (1<<REFS0) | HighPin;	// switch Mux to High-Pin
   ADCSRA = (0<<ADEN) | (0<<ADSC) | (0<<ADFR) | (1<<ADIF) | (1<<ADPS1) | (1<<ADPS0); //disable ADC

   ovcnt = 0;
// setup Counter1
   TCCR1A = 0;			// set Counter1 to normal Mode
   TCNT1 = 0;				//set Counter to 0
   TIFR = (1<<OCF2) | (1<<TOV2) | (1<<ICF1) | (1<<OCF1A) | (1<<OCF1B) | (1<<TOV1) | (1<<TOV0);
   R_PORT = HiPinR_H;           	// HighPin �ber R_H auf Plus
   if(PartFound == PART_FET)
     { // Kondensator �ber R_H langsam laden, dabei freien Pin (Drain) f�r Gate-Kapazit�ts-Messung auf Masse
      ADC_DDR = (7 & ~(1<<HighPin)) | TXD_MSK;	// nur HighPin freigeben
     }
   else
     {
      ADC_DDR = LoADC;	// nur LoADC Pin auf 0 halten, Kondensator �ber R_H langsam laden
     }
				// Widerstand l�d den Kondensator schon, Z�hler l�uft nicht!
				// wdt_reset hier nur zur Zeitverz�gerung,
				// um Messgenauigkeit kleiner Kapazit�ten zu verbessern
				// (253pF,137pF) ohne wdt-reset Verz�gerung
   wdt_reset();		// (246pF,130pF)
   wdt_reset();		// (238pF,123pF) 
   wdt_reset();		// (231pF,115pF) jetzt erst Timer starten
// Zum Abgleich, wieviele Verz�gerungs-Befehle notwendig sind, ist es ratsam
// mit zwei identischen kleinen Kapazit�ten (z.B. 220pF) zu messen:
// In Reihe geschaltet sollte die Anzeige etwa die H�lfte der gemessenen Einzelkapazit�t
// anzeigen. Wird bei der H�lfte mehr angezeigt, m�ssen gegebenenfalls mehr Verz�gerungen
// zwischengeschaltet werden, anderenfalls weniger.
// Dieses Verfahren ist ein Programmier-Trick, um eine anschliessende long-Subtraktion zu vermeiden.
// Bei meinen Tests wurde bei einem 220pF Kondensator 231pF angezeigt,
// bei der Reihenschaltung wurden 115pF angezeigt.
// Nebenbei bemerkt werden von einem �lteren Voltcraft M-4650B Multimeter bei
// dem gleichen Kondensator 253pF angezeigt, bei einem Nullwert von 26pF
// wenn ich den Nullwert ber�cksichtige sind es also 227pF.
// da ist die bei bestem Abgleich erreichte Anzeige des Transistor-Testers von 231pF 
// richtig gut, zumal die Aufl�sung des Messverfahrens hier nur ca. 7pF betr�gt!
// Verbesserung der Aufl�sung ist m�glich, wenn der Z�hler auf h�herer Frequenz l�uft,
// ob damit auch eine Verbesserung der Messgenauigkeit erzielt werden kann, k�nnte man 
// durch einen Versuch bei z.B. 8MHz ermitteln.
   TCCR1B = (0<<ICNC1) | (0<<ICES1) | (1<<CS10); //Start Counter 1MHz
//******************************
   while(1)
     {  // Warten, bis Input Capture gesetzt
      ii = TIFR;			//Timer Flags lesen
      if (ii & (1<<ICF1))  break;
      if((ii & (1<<TOV1)))
        {  // Timer �berlauf, 65.536 ms
         TIFR = (1<<TOV1);		// Reset OV Flag
         wdt_reset();
         ovcnt++;
         if(ovcnt == 250) break; 	//Timeout f�r Ladung, �ber 16s
		// eigentlich d�rfte nur ca. 26 erreicht werden wegen R_L Test
        }
     }
   TCCR1B = (0<<ICNC1) | (0<<ICES1) | (0<<CS10);  // Halte Timer an
   TIFR = (1<<ICF1);			// Reset Input Capture
   tmpint = ICR1;		// get Input Capture Counter
// mit aktuellem Counter pr�fen, ob noch ein �bertrag
   if((TCNT1 > tmpint) && (ii & (1<<TOV1)))
     { // dieser OV wurde noch nicht gez�hlt, war aber vor Input Capture
      TIFR = (1<<TOV1);		// Reset OV Flag
      ovcnt++;
     }
   R_PORT = 0;			//Kondensator wieder entladen
   cval = CombineBI2Long(ovcnt, tmpint);
   cval *= H_CAPACITY_FACTOR;	// 724
   cval /= 100;
   cpre = 0;	// pF Ausgabe
#if DebugOut == 10
   R_DDR = 0;		// Hochohmig
   Line4();
   lcd_clear_line();
   Line4();
   lcd_ziff(LowPin);
   lcd_data('c');
   lcd_ziff(HighPin);
   lcd_data(' ');
   lcd_string(ultoa(cval,outval,10));
   lcd_data('p');
   for(ii=0;ii<3;ii++) wait1000ms();
#endif
   R_DDR = HiPinR_L; 		//High-Pin �ber R_L auf Masse
   if((ovcnt == 0) && (tmpint < 10))
     {
#if DebugOut == 10
     lcd_data('<');
     lcd_data(' ');
     wait1000ms();
#endif
      goto keinC;	//Kapazit�t zu gering < 72pF
     }
   // end Niedrige Kapazit�t

 
markC:
   PartFound = PART_CAPACITOR;	//Kondensator gefunden
   ca = LowPin;
   cb = HighPin;

keinC:
  //Kondensator wieder entladen
  ADCSRA = (1<<ADEN) | (0<<ADSC) | (0<<ADFR) | (1<<ADIF) | (1<<ADPS1) | (1<<ADPS0); //enable ADC
  EntladePins();		// Kondensator entladen
  //Fertig
  // alles hochohmig schalten
  ADC_DDR =  TXD_MSK;				
  ADC_PORT = TXD_VAL;
  R_DDR = 0;
  R_PORT = 0; 
 } // end ReadCapacity()
