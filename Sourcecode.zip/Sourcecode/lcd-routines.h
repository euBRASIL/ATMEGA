#include "config.h"

// Ansteuerung eines HD44780 kompatiblen LCD im 4-Bit-Interfacemodus
// http://www.mikrocontroller.net/articles/AVR-GCC-Tutorial
//


//LCD
void lcd_ziff(unsigned char temp);
void lcd_data(unsigned char temp1);
void lcd_command(unsigned char temp1);
void lcd_send(unsigned char data);
void lcd_string(char *data);
void lcd_enable(void);
void lcd_init(void);
void lcd_clear(void);
void lcd_pgm_string(const unsigned char *data);
void lcd_pgm_customchar(const unsigned char *chardata);
void lcd_clear_line(void);		// only for DebugOut

//Software-UART
extern void uart_putc(uint8_t data);
void uart_newline(void);


//LCD-Befehle
#define CMD_SetEntryMode         0x04
#define CMD_SetDisplayAndCursor  0x08
#define CMD_SetIFOptions         0x20
#define CMD_SetCGRAMAddress      0x40    // f�r Custom-Zeichen
#define CMD_SetDDRAMAddress      0x80    // zum Cursor setzen

//Makros f�r LCD
#define Line1() lcd_command((uint8_t)(CMD_SetDDRAMAddress))		//An den Anfang der 1. Zeile springen
#define Line2() lcd_command((uint8_t)(CMD_SetDDRAMAddress + 0x40))	//An den Anfang der 2. Zeile springen
#define Line3() lcd_command(((uint8_t)CMD_SetDDRAMAddress + 0x14))	//An den Anfang der 3. Zeile springen
#define Line4() lcd_command(((uint8_t)CMD_SetDDRAMAddress + 0x54))	//An den Anfang der 4. Zeile springen
#define lcd_aus() lcd_command(0x08)
#define lcd_ein() lcd_command(0x0c)
#define lcd_shift_right() lcd_command(0x1c)
#define lcd_shift_left() lcd_command(0x18)

#define SetCursor(y, x) lcd_command((uint8_t)(CMD_SetDDRAMAddress + (0x40*(y-1)) + x)) //An eine bestimmte Position springen

#define LCDLoadCustomChar(addr) lcd_command(CMD_SetCGRAMAddress | (addr<<3))	//Custom-Zeichen laden

//Eigene Zeichen
#define LCD_CHAR_DIODE  1	//Dioden-Icon; wird als Custom-Character erstellt
#define LCD_CHAR_DIODE2  2	//Dioden-Icon; wird als Custom-Character erstellt

#ifdef LCD_CYRILLIC
	#define LCD_CHAR_OMEGA  4	//Omega-Zeichen als Custom-Zeichen erzeugen
	#define LCD_CHAR_U  5		//�-Zeichen als Custom-Zeichen erzeugen
#else
	#define LCD_CHAR_OMEGA  244	//Omega-Zeichen
	#define LCD_CHAR_U  228		//�-Zeichen
#endif
  
// LCD Befehle
 
#define CLEAR_DISPLAY 0x01
 
// Pinbelegung f�r das LCD, an verwendete Pins anpassen
 
#define LCD_PORT      PORTD
#define LCD_DDR       DDRD
#define LCD_RS        PD4
#define LCD_EN1       PD5
