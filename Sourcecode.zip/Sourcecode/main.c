#include <avr/io.h>
#include "lcd-routines.h"
#include "wait1000ms.h"
#include "config.h"
#include <util/delay.h>
#include <avr/sleep.h>
#include <stdlib.h>
#include <string.h>
//#include <avr/eeprom.h>
#include <avr/pgmspace.h>
#include <avr/wdt.h>
#include <math.h>
//#define DebugOut 1		// wenn gesetzt, Ausgabe von Spannungen im Leerlauf mit R_H 
//#define DebugOut 2		// wenn gesetzt, Ausgabe von  Pin-Spannungen mit geschalteten R_L 
//#define DebugOut 3		// wenn gesetzt, Zwischenausgaben bei Widerstandmessung in Zeile 2
//#define DebugOut 4		// wenn gesetzt, Spannungsausgabe bei Diodenmessung in Zeilen 3+4
//#define DebugOut 5		// wenn gesetzt, Zwischenausgaben der TransistorUntersuchung in Zeile 2+3
//#define DebugOut 10		// wenn gesetzt, Zwischenausgaben in ReadCapacity in Zeilen 3+4 
/*########################################################################################
	Konfigurations-Einstellungen
*/

/* Port f�r die Test-Pins
  Dieser Port muss �ber einen ADC verf�gen (beim Mega8 also PORTC).
  F�r die Test-Pins m�ssen die unteren 3 Pins dieses Ports benutzt werden.
  Bitte die Definitionen f�r TP1, TP2 und TP3 nicht �ndern!
*/

#define ADC_PORT PORTC
#define ADC_DDR DDRC
#define ADC_PIN PINC
#define TP1 PC0
#define TP2 PC1
#define TP3 PC2

  /*Einstellungen f�r Kapazit�tsmessung (nur f�r ATMega8 interessant)
  Der Test, ob ein Kondensator vorhanden ist, dauert relativ lange, mit �ber 50ms je Testvorgang ist zu rechnen
  Bei allen 6 m�glichen Testvorg�ngen ergibt das eine Verl�ngerung der Testdauer um ca 0,3s bis 0,5s.
  Mit CAP_TEST_MODE lassen sich die durchgef�hrten Tests festlegen.

  Bedeutungen der Bits (7 = MSB):
  7:6 Nicht verwendet

  5:4 Test-Modus
  00: Kondensator-Messung deaktiviert
  01: Kondensator-Messung f�r eine einstellbare Pin-Kombination (in beide Richtungen); verl�ngert Testdauer um ca. 120...200ms
  10: Kondensator-Messung f�r alle 6 Pin-Kombinationen; verl�ngert Testdauer um ca. 300...500ms
  
  3:2 Erster Pin der gew�hlten Pin-Kombination (0...2), nur entscheidend wenn Bits 5:4 = 01

  1:0 Zweiter Pin der gew�hlten Pin-Kombination (0...2), nur entscheidend wenn Bits 5:4 = 01
  */
  #define CapTestMode  0x12         //Messung f�r alle 6 Pin-Kombinationen



/*
  Genaue Werte der verwendeten Widerst�nde in Ohm.
  Der Nennwert f�r R_L ist 680 Ohm, f�r R_H 470kOhm.
  
  Um das Programm auf Abweichungen von diesen Werten (z.B. durch Bauteiltoleranzen)
  zu kalibrieren, die Widerstandswerte in Ohm in die folgenden Defines eintragen:
*/
  #define R_L_VAL 680		// Normwert 680 Ohm
  #define R_H_VAL 4700		// Normwert 470000 Ohm, durch 100 dividiert

  #define PIN_R	 20		// Gesch�tzter Innenwiderstand PORT Ausgang


  /*	Faktoren f�r die Kapazit�tsmessung bei Kondensatoren
    Diese Faktoren h�ngen von Fertigungstoleranzen des AVR ab und m�ssen somit ggf. angepasst werden
    H_CAPACITY_FACTOR ist f�r die Messung mit 470k-Widerstand (geringe Kapazit�t)
    L_CAPACITY_FACTOR ist f�r die Messung mit 680-Ohm-Widerstand (hohe Kapazit�t)
  Gemessen wird die Zeit (t) in �s bis zum Erreichen der Vergleichsspannung (1.3V)
  des analogen Komparators.
  Die Spannung am Kondensator steigt nach Uc = VCC * (1 - e**(-t/T))
  Die 1.3V werden somit nach t = -ln(3.7/5)*T  = 0.3011*T erreicht. 
  Zeitkonstante T = R * C ; also
  C = T / R
  f�r die 470 kOhm  ergibt sich nach C = t / (0.3011 * 470000)
  H_Fakt = 707/100 f�r das Ergebnis in pF

  F�r die 680 Ohm sind die Verh�ltnisse komplizierter.
  zum Zeitpunkt des Komparator-Schaltens fliesst noch deutlich Strom, der
  einen zus�tzlichen Spannungsanstieg des LowPin zur Folge hat.
   = (VCC - 1.3V) / (R_L + PIN_R) * PIN_R = 105mV
  Der Komparator schaltet also bei einer Kondensator-Spannung von etwa 1.2V!!!
  Das ergibt als Schaltzeit t = -ln((5-1.2)/5)*T = 0.274437*T .
  f�r die 680 Ohm ergibt sich nach C = t / (0.274437 * (680 + PIN_R + PIN_R))
  oder C = Z * 5.060869   (253/50)
  
    Der gesamte Messbereich ist ca. 100pF bis 80mF.
  */
//#define H_CAPACITY_FACTOR  707
#define H_CAPACITY_FACTOR  724
//#define L_CAPACITY_FACTOR  253
#define L_CAPACITY_FACTOR  273

// durch Faktoren wird der ADC-Wert so umgerechnet, dass die Spannungen in mV gemessen werden!
// alle Abfragen wurden durch solche mV Abfragen ersetzt.
#define U_VCC 5001		// Maximalwert der ADC-Messung


/*########################################################################################
Ende der Konfigurations-Einstellungen
*/

/*Strings im PROGMEM
Beim Hinzuf�gen weiter Sprachen m�ssen alle Strings mit "�"-Zeichen (ASCII 0x80) auf gleiche L�nge gebracht werden,
sonst gibt es Probleme mit der LCD-Anzeige bei den verschiedenen Sprachen!
*/

#if defined(GERMAN)	//deutsch
  unsigned char TestRunning[] PROGMEM = "Testen...";
  unsigned char BatWeak[] PROGMEM = "schwach";
  unsigned char BatEmpty[] PROGMEM = "leer!";
  unsigned char TestFailed2[] PROGMEM = "defektes ";
  unsigned char Bauteil[] PROGMEM = "Bauteil";
  unsigned char Diode[] PROGMEM = "Diode: ";
  unsigned char Dioden[] PROGMEM = "Dioden ";
  unsigned char GAK[] PROGMEM = "GAK=";
  unsigned char Triac[] PROGMEM = "Triac";
  unsigned char Thyristor[] PROGMEM = "Thyristor";
  unsigned char Unknown[] PROGMEM = " unbek.";
  unsigned char TestFailed1[] PROGMEM = "Kein,unbek. oder";
   unsigned char OrBroken[] PROGMEM = "oder defekt ";
   unsigned char Resistor[] PROGMEM = "Widerst: ";
   unsigned char Capacitor[] PROGMEM = "Kondensator: ";

#elif defined(ENGLISH)	//englisch
  unsigned char TestRunning[] PROGMEM = "Testing...";
  unsigned char BatWeak[] PROGMEM = "weak";
  unsigned char BatEmpty[] PROGMEM = "empty!";
  unsigned char TestFailed2[] PROGMEM = "damaged ";
  unsigned char Bauteil[] PROGMEM = "part";
  unsigned char Diode[] PROGMEM = "Diode: ";
  unsigned char Dioden[] PROGMEM = "Diodes ";
  unsigned char GAK[] PROGMEM = "GAC=";
  unsigned char Triac[] PROGMEM = "Triac";
  unsigned char Thyristor[] PROGMEM = "Thyristor";
  unsigned char Unknown[] PROGMEM = " unknown";
  unsigned char TestFailed1[] PROGMEM = "No, unknown, or";
   unsigned char OrBroken[] PROGMEM = "or damaged ";
   unsigned char Resistor[] PROGMEM = "Resistor: ";
   unsigned char Capacitor[] PROGMEM = "Capacitor: ";

#elif defined(POLISH)	//polnisch
  unsigned char TestRunning[] PROGMEM = "Testowanie...";
  unsigned char BatWeak[] PROGMEM = "slaba";
  unsigned char BatEmpty[] PROGMEM = "za slaba";
  unsigned char TestFailed2[] PROGMEM = "lub uszkodz.";
  unsigned char Bauteil[] PROGMEM = "Element";
  unsigned char Diode[] PROGMEM = "Dioda: ";
  unsigned char Dioden[] PROGMEM = "Diody  ";
  unsigned char GAK[] PROGMEM = "GAK=";
  unsigned char Triac[] PROGMEM = "Triak";
  unsigned char Thyristor[] PROGMEM = "Tyrystor";
  unsigned char Unknown[] PROGMEM = " nieznany";
  unsigned char TestFailed1[] PROGMEM = "brak elementu";
   unsigned char OrBroken[] PROGMEM = "lub uszkodz. ";
   unsigned char Resistor[] PROGMEM = "Opornosc: ";
   unsigned char Capacitor[] PROGMEM = "Pojemnosc: ";

#elif defined(CZECH)  //tschechisch 
  unsigned char TestRunning[] PROGMEM = "Probiha mereni...";
  unsigned char BatWeak[] PROGMEM = "slaba";
  unsigned char BatEmpty[] PROGMEM = "prazdna!";
  unsigned char TestFailed2[] PROGMEM = "vadna ";
  unsigned char Bauteil[] PROGMEM = "soucastka";
  unsigned char Diode[] PROGMEM = "Dioda: ";
  unsigned char Dioden[] PROGMEM = "Diody  ";
  unsigned char GAK[] PROGMEM = "GAK=";
  unsigned char Triac[] PROGMEM = "Triak";
  unsigned char Thyristor[] PROGMEM = "Tyristor";
  unsigned char Unknown[] PROGMEM = " neznama";
  unsigned char TestFailed1[] PROGMEM = "Zadna, neznama";
   unsigned char OrBroken[] PROGMEM = "nebo vadna ";
   unsigned char Resistor[] PROGMEM = "Rezistor: ";
   unsigned char Capacitor[] PROGMEM = "Kondenzator: ";

#elif defined(SLOVAK)  //slowakisch 
  unsigned char TestRunning[] PROGMEM = "PREBIEHA TEST";
  unsigned char BatWeak[] PROGMEM = "slaba";
  unsigned char BatEmpty[] PROGMEM = "prazdna!";
  unsigned char TestFailed2[] PROGMEM = "vadna ";
  unsigned char Bauteil[] PROGMEM = "suciastka!";
  unsigned char Diode[] PROGMEM = "Dioda: ";
  unsigned char DualDiode[] PROGMEM = "Diody  ";
  unsigned char GAK[] PROGMEM = "GAK=";
  unsigned char Triac[] PROGMEM = "Triak";
  unsigned char Thyristor[] PROGMEM = "Tyristor";
  unsigned char Unknown[] PROGMEM = " neznama";
  unsigned char TestFailed1[] PROGMEM = "Ziadna, neznama";
   unsigned char OrBroken[] PROGMEM = "alebo vadna ";
   unsigned char Resistor[] PROGMEM = "Rezistor: ";
   unsigned char Capacitor[] PROGMEM = "Kondenzator: ";
#endif



//Sprachunabh�ngige Strings
unsigned char Bat[] PROGMEM = "Bat. ";
unsigned char OK[] PROGMEM = "OK";
unsigned char mosfet[] PROGMEM = "-MOS";
unsigned char jfet[] PROGMEM = "JFET";
unsigned char GateCap[] PROGMEM = " C=";
unsigned char hfestr[] PROGMEM ="hFE=";
unsigned char NPN[] PROGMEM = "NPN ";
unsigned char PNP[] PROGMEM = "PNP ";
unsigned char ebcstr[] PROGMEM = " EBC=";
unsigned char gds[] PROGMEM = "GDS=";
unsigned char Uf[] PROGMEM = "Uf=";
unsigned char vt[] PROGMEM = "Vt=";
unsigned char AnKat[] PROGMEM = {'-', LCD_CHAR_DIODE, '-', 0};
unsigned char KatAn[] PROGMEM = {'-', LCD_CHAR_DIODE2, '-', 0};
unsigned char TestTimedOut[] PROGMEM = "Timeout!";

unsigned char DiodeIcon[] PROGMEM = { 0x11,
				     0x19,
				     0x1d,
				     0x1f,
				     0x1d,
				     0x19,
				     0x11,
				     0x00};	// Diode-Icon Anode links

unsigned char DiodeIcon2[] PROGMEM = { 0x11,
				     0x13,
				     0x17,
				     0x1f,
				     0x17,
				     0x13,
				     0x11,
				     0x00};	// Diode-Icon Anode rechts

unsigned char PinRLtab[] PROGMEM = { (1<<(TP1*2)),
				     (1<<(TP2*2)),
				     (1<<(TP3*2))};	// Tabelle der R-L Schaltbefehle Pin 0,1,2

unsigned char PinADCtab[] PROGMEM = { (1<<0),
				     (1<<1),
				     (1<<2)};	// Tabelle der ADC-Pins Schaltbefehle Pin 0,1,2

#ifdef LCD_CYRILLIC	//Omega- und �-Zeichen als Custom-Zeichen erzeugen, weil diese Zeichen im kyrillischen Zeichensatz nicht enthalten sind
  unsigned char CyrillicOmegaIcon[] PROGMEM = {0,0,14,17,17,10,27,0};	//Omega
  unsigned char CyrillicMuIcon[] PROGMEM = {0,17,17,17,19,29,16,16};	//�
#endif

#ifdef R_MESS
  unsigned char T132[] PROGMEM = "1:3:2";
  unsigned char T123[] PROGMEM = "1:2:3";
  unsigned char T213[] PROGMEM = "2:1:3";
#endif

//Ende der EEPROM-Strings

//Watchdog
#define WDT_enabled
/* Wird das Define "WDT_enabled" entfernt, wird der Watchdog beim Programmstart
 nicht mehr aktiviert. Das ist f�r Test- und Debuggingzwecke sinnvoll.
 F�r den normalen Einsatz des Testers sollte der Watchdog aber unbedingt aktiviert werden!
*/


struct Diode {
  uint8_t Anode;
  uint8_t Cathode;
  unsigned int Voltage;
};

void CheckPins(uint8_t HighPin, uint8_t LowPin, uint8_t TristatePin);
void ChargePin10ms(uint8_t PinToCharge, uint8_t ChargeDirection);
unsigned int ReadADC(uint8_t mux);
unsigned int W5msReadADC(uint8_t mux);
unsigned int W20msReadADC(uint8_t mux);
void lcd_show_format_cap(char outval[]);
void ReadCapacity(uint8_t HighPin, uint8_t LowPin);		//Kapazit�tsmessung nur auf Mega8 verf�gbar
void UfAusgabe(uint8_t bcdchar);	// Ausgabe der Schwellwertspannung(en) Uf
void RvalOut(uint8_t ii);		// Ausgabe der Widerstandswerte
void EntladePins();			// Kondensatoren entladen


#define R_DDR DDRB
#define R_PORT PORTB

/* Port f�r die Testwiderst�nde
  Die Widerst�nde m�ssen an die unteren 6 Pins des Ports angeschlossen werden,
  und zwar in folgender Reihenfolge:
  RLx = 680R-Widerstand f�r Test-Pin x
  RHx = 470k-Widerstand f�r Test-Pin x

  RL1 an Pin 0
  RH1 an Pin 1
  RL2 an Pin 2
  RH2 an Pin 3
  RL3 an Pin 4
  RH3 an Pin 5

*/



#define ON_DDR DDRD
#define ON_PORT PORTD
#define ON_PIN_REG PIND
#define ON_PIN PD6	//Pin, der auf high gezogen werden muss, um Schaltung in Betrieb zu halten
#define RST_PIN PD7	//Pin, der auf low gezogen wird, wenn der Einschalt-Taster gedr�ckt wird

//Bauteile
#define PART_NONE 0
#define PART_DIODE 1
#define PART_TRANSISTOR 2
#define PART_FET 3
#define PART_TRIAC 4
#define PART_THYRISTOR 5
#define PART_RESISTOR 6
#define PART_CAPACITOR 7

//Ende (Bauteile)
//Spezielle Definitionen f�r Bauteile
//FETs
#define PART_MODE_N_E_MOS 1
#define PART_MODE_P_E_MOS 2
#define PART_MODE_N_D_MOS 3
#define PART_MODE_P_D_MOS 4
#define PART_MODE_N_JFET 5
#define PART_MODE_P_JFET 6

//Bipolar
#define PART_MODE_NPN 1
#define PART_MODE_PNP 2


struct Diode diodes[6];
uint8_t NumOfDiodes;

struct {
unsigned int hfe[2];		//Verst�rkungsfaktor
//unsigned int uBE[2];		//B-E-Spannung f�r Transistor
uint8_t b,c,e;			//Anschl�sse des Transistors
}trans;

unsigned long lhfe;		//Verst�rkungsfaktor
uint8_t PartReady;		//Bauteil fertig erkannt
uint8_t PartMode;
uint8_t tmpval, tmpval2;

#ifdef WITH_UART
#define TXD_MSK (1<<TxD)
#else
#define TXD_MSK 0
#endif

#ifdef SWUART_INVERT
  #define TXD_VAL 0
#else
  #define TXD_VAL TXD_MSK
#endif

#ifdef R_MESS
struct resis_t{
 unsigned long rx;		// Widerstandswert RX  
 uint8_t kfl;			// 1, wenn Messung mit R_L, sonst 100
 uint8_t ra,rb;			// Pinne von RX
 uint8_t rt;			// Tristate-Pin
} resis[3];
 unsigned int rxv, rtst;
 unsigned int rvmax;
#endif

 #if DebugOut == 1
  unsigned char URH[] PROGMEM = "URH";
 #endif
 #if DebugOut == 2
  unsigned char URH[] PROGMEM = "URL";
 #endif
 #if (DebugOut == 1) || (DebugOut == 2)
  unsigned int hivolt[3];	// Ergebnis der Spannungsmessungen an den HighPins
  unsigned int lovolt[3];	// Ergebnis der Spannungsmessungen an den LowPins
 #endif

#ifdef C_MESS
  unsigned char C_Prefix_tab[] PROGMEM = { 'p','n',LCD_CHAR_U,'m'}; // pF,nF,�F,mF
  char outval2[10];		// f�r ASCII-Ausgabe 
#endif

uint8_t ii;			// Hilfsz�hler
unsigned long cval;		// gemessener Kapazit�tswert
uint8_t cpre;			//Prefix f�r Farad Angabe 0=p, 1=n, 2=�, 3=m

uint8_t PartFound;	 	//das gefundene Bauteil
uint8_t NumOfR;			//Anzahl der gefundenen Widerst�nde
uint8_t ca, cb;			//Kondensator-Pins
char outval[10];
//unsigned int adcv[4];
unsigned int gthvoltage;	//Gate-Schwellspannung


//Programmbeginn
int main(void) {
  //Einschalten
  ON_DDR = (1<<ON_PIN);
  ON_PORT = (1<<ON_PIN) | (1<<RST_PIN);	//Strom an und Pullup f�r Reset-Pin
  uint8_t tmp;
  //ADC-Init
  ADCSRA = (1<<ADEN) | (1<<ADPS1) | (1<<ADPS0);	//Vorteiler=8
  lcd_init();
	

  wdt_disable();
  if(MCU_STATUS_REG & (1<<WDRF))
    {  /* �berpr�fen auf Watchdog-Reset 
          Das tritt ein, wenn der Watchdog 2s nicht zur�ckgesetzt wurde
          Kann vorkommen, wenn sich das Programm in einer Endlosschleife "verheddert" hat.  */
     lcd_pgm_string(TestTimedOut);	//Timeout-Meldung
     wait1000ms();
     wait1000ms();
     wait1000ms();
     ON_PORT = 0;		//Abschalten!
     return 0;
    }
  LCDLoadCustomChar(LCD_CHAR_DIODE);	//Custom-Zeichen
  lcd_pgm_customchar(DiodeIcon);
  LCDLoadCustomChar(LCD_CHAR_DIODE2);	//Custom-Zeichen
  lcd_pgm_customchar(DiodeIcon2);
  
#ifdef LCD_CYRILLIC
  //bei kyrillischen LCD-Zeichensatz Omega- und �-Zeichen laden
  LCDLoadCustomChar(LCD_CHAR_OMEGA);	//Custom-Zeichen
  //Omega-Zeichen in LCD laden
  lcd_pgm_customchar(CyrillicOmegaIcon);
  LCDLoadCustomChar(LCD_CHAR_U);	//Custom-Zeichen
  //�-Zeichen in LCD laden
  lcd_pgm_customchar(CyrillicMuIcon);
#endif
  Line1();	//1. Zeile

//*****************************************************************
//Einsprungspunkt, wenn Start-Taste im Betrieb erneut gedr�ckt wird
  start:
  PartFound = PART_NONE;
  NumOfR = 0;
  NumOfDiodes = 0;
  PartReady = 0;
  PartMode = 0;
  lcd_clear();
  ADC_DDR = TXD_MSK;		//Software-UART aktivieren
#ifdef C_MESS
  ca = 0;
  cb = 0;
#endif
  uart_newline();
  //Versorgungsspannung messen
  ReadADC(5 | (1<<REFS1));	//Dummy-Readout
  trans.hfe[0] = ReadADC(5 | (1<<REFS1)); 	//mit interner Referenz
    				// 5001 = 2,56V, durch Teiler 10,317mV
  lcd_pgm_string(Bat);		//Anzeige: "Bat. "
  utoa(trans.hfe[0]/48, outval, 10);	// nur 2 Stellen ausgeben
  lcd_data(outval[0]);
  lcd_data('.');
  lcd_data(outval[1]);
  lcd_data('V');
  lcd_data(' ');
  if (trans.hfe[0] < 3422)
    {  //Vcc < 7,3V; Warnung anzeigen
     if(trans.hfe[0] < 2933)
       {  //Vcc <6,3V; zuverl�ssiger Betrieb nicht mehr m�glich
        lcd_pgm_string(BatEmpty);	//Batterie leer!
        wait1000ms();
        PORTD = 0;			//abschalten
        return 0;
       }
     lcd_pgm_string(BatWeak);		//Batterie schwach
    }
  else
    { // Batterie-Spannung ausreichend
     lcd_pgm_string(OK); 		// "OK"
    }
  //Test beginnen
  Line2();
#ifndef DebugOut
  lcd_pgm_string(TestRunning);		//String: Test l�uft
#endif
#ifdef WDT_enabled
  wdt_enable(WDTO_2S);		//Watchdog an
#endif
  //Alle 6 Kombinationsm�glichkeiten f�r die 3 Pins pr�fen
  EntladePins();		// evtl. vorhandene Restladung entladen
  CheckPins(TP1, TP2, TP3);
  CheckPins(TP1, TP3, TP2);
  CheckPins(TP2, TP1, TP3);
  CheckPins(TP2, TP3, TP1);
  CheckPins(TP3, TP2, TP1);
  CheckPins(TP3, TP1, TP2);
#ifdef DebugOut
  wait1000ms();
#endif
#if (DebugOut == 1) || (DebugOut == 2)

#if DebugOut == 1
     // Messung, wie gut R_H die Spannung auf Ground und VCC zieht
#warning "Messung, wie gut wird mit R_H GND oder VCC Potential erreicht?"
     R_DDR = 2<<(TP1*2);		//Low-Pin auf Ausgang und �ber R_H auf Masse
     lovolt[0] = W5msReadADC(TP1);
     R_PORT = 2<<(TP1*2);
     hivolt[0] = W5msReadADC(TP1);

     R_PORT = 0;
     R_DDR = 2<<(TP2*2);		//Low-Pin auf Ausgang und �ber R_H auf Masse
     lovolt[1] = W5msReadADC(TP2);
     R_PORT = 2<<(TP2*2);
     hivolt[1] = W5msReadADC(TP2);

     R_PORT = 0;
     R_DDR = 2<<(TP3*2);		//Low-Pin auf Ausgang und �ber R_H auf Masse
     lovolt[2] = W5msReadADC(TP3);
     R_PORT = 2<<(TP3*2);
     hivolt[2] = W5msReadADC(TP3);
#endif
#if DebugOut == 2
#warning "Innenwiderstands-Messung der Ausgabe-Ports"
     // Messung des Innenwiderstandes der Ports
     ADC_DDR = 7 | TXD_MSK;		//alle ADC-Pins auf Ausgang 0V
     ADC_PORT = TXD_VAL;
     R_PORT = 1<<(TP1*2) | 1<<(TP2*2)| 1<<(TP3*2); // Alle R_L-PORTS auf VCC
     R_DDR = 1<<(TP1*2);		//Low-Pin auf Ausgang und �ber R_L auf VCC
     lovolt[0] = W5msReadADC(TP1);

     R_DDR = 1<<(TP2*2);		//High-Pin auf Ausgang und �ber R_L auf VCC
     lovolt[1] = W5msReadADC(TP2);

     R_DDR = 1<<(TP3*2);		//High-Pin auf Ausgang und �ber R_L auf VCC
     lovolt[2] = W5msReadADC(TP3);

     R_PORT = 0;			// alle R-Ports auf Masse
     ADC_PORT = 7 | TXD_VAL;		// alle ADC-Ports auf VCC
     R_DDR = 1<<(TP3*2);		//High-Pin auf Ausgang und �ber R_L auf Masse
     hivolt[2] = U_VCC - W5msReadADC(TP3);

     R_DDR = 1<<(TP2*2);		//High-Pin auf Ausgang und �ber R_L auf Masse
     hivolt[1] = U_VCC - W5msReadADC(TP2);

     R_DDR = 1<<(TP1*2);			//Low-Pin auf Ausgang und �ber R_L auf Masse
     hivolt[0] = U_VCC - W5msReadADC(TP1);

#endif
     ADC_DDR =  TXD_MSK;		//alle-Pins auf Input
     ADC_PORT = TXD_VAL;		// alle ADC-Ports auf GND
     R_DDR = 0;				// alle R-Ports auf Input
     R_PORT = 0;
// Testausgabe
  for(ii=0;ii<3;ii++)
    {
     lcd_clear();
     Line1();
     lcd_pgm_string(URH);		//Anzeige: "URH" oder "URL"
     lcd_data(ii+'0');
     lcd_data('=');
     lcd_string(utoa(lovolt[ii], outval, 10));
     lcd_data(',');
     lcd_string(utoa(hivolt[ii], outval, 10));
     wait1000ms();
     wait1000ms();
    }
#endif
  
#ifdef C_MESS
 #if (CapTestMode & 0x30) > 0
  //Separate Messung zum Test auf Kondensator
  if(((PartFound == PART_NONE) || (PartFound == PART_RESISTOR) || (PartFound == PART_DIODE)) )
    { //Kondensator entladen; sonst ist evtl. keine Messung m�glich
     EntladePins();		// evtl. vorhandene Restladung entladen
  #if (CapTestMode & 0x30) == 0x10
     // nur mit 2 Pins Kapazit�ten messen
     ReadCapacity((CapTestMode & 0x03),  (CapTestMode & 0x0c)>>2 );
  #else
     //Kapazit�t in allen 6 (3) Pin-Kombinationen messen
     ReadCapacity(TP3, TP1);
     ReadCapacity(TP3, TP2);
//     ReadCapacity(TP2, TP3);
     ReadCapacity(TP2, TP1);
//     ReadCapacity(TP1, TP3);
//     ReadCapacity(TP1, TP2);
  #endif
    }
 #endif
#endif
  //Fertig, jetzt folgt die Auswertung
  lcd_clear();
  Line1();
  if(PartFound == PART_DIODE)
    {
     if(NumOfDiodes == 1)
       { //Standard-Diode
        lcd_pgm_string(Diode);		//"Diode: "
        lcd_ziff(diodes[0].Anode);
        lcd_pgm_string(AnKat);		//"->|-"
        lcd_ziff(diodes[0].Cathode);
        UfAusgabe(0x70);
        goto end;
       }
     else if(NumOfDiodes == 2)
       { //Doppeldiode
        lcd_data('2');
        lcd_pgm_string(Dioden);		//"Dioden "
        if(diodes[0].Anode == diodes[1].Anode)
          { //Common Anode
           lcd_ziff(diodes[0].Cathode);
           lcd_pgm_string(KatAn);	//"-|<-"
           lcd_ziff(diodes[0].Anode);
           lcd_pgm_string(AnKat);	//"->|-"
           lcd_ziff(diodes[1].Cathode);
           UfAusgabe(0x01);
           goto end;
          }
        else if(diodes[0].Cathode == diodes[1].Cathode)
          { //Common Cathode
           lcd_ziff(diodes[0].Anode);
           lcd_pgm_string(AnKat);	//"->|-"
	   lcd_ziff(diodes[0].Cathode);
           lcd_pgm_string(KatAn);	//"-|<-"
           lcd_ziff(diodes[1].Anode);
           UfAusgabe(0x01);
           goto end;
          }
        else if ((diodes[0].Cathode == diodes[1].Anode) && (diodes[1].Cathode == diodes[0].Anode))
          { //Antiparallel
           lcd_ziff(diodes[0].Anode);
           lcd_pgm_string(AnKat);	//"->|-"
           lcd_ziff(diodes[0].Cathode);
           lcd_pgm_string(AnKat);	//"->|-"
           lcd_ziff(diodes[1].Cathode);
           UfAusgabe(0x01);
//           lcd_pgm_string(Antiparallel);	//"Antiparallel"
           goto end;
          }
       }
     else if(NumOfDiodes == 3)
       { //Serienschaltung aus 2 Dioden; wird als 3 Dioden erkannt
        trans.b = 3;
        trans.c = 3;
        /* �berpr�fen auf eine f�r eine Serienschaltung von 2 Dioden m�gliche Konstellation
          Es stimmt nur einmal die Pin-Nr. einer Kathode mit einer Anode �berein.
          Das kommmt daher, dass die Dioden als 2 Einzeldioden und ZUS�TZLICH als eine "gro�e" Diode erkannt werden.
        */
        if(diodes[0].Cathode == diodes[1].Anode)
          {
           trans.b = 0;
           trans.c = 1;
          }
        if(diodes[0].Anode == diodes[1].Cathode)
          {
           trans.b = 1;
           trans.c = 0;
          }
        if(diodes[0].Cathode == diodes[2].Anode)
          {
           trans.b = 0;
           trans.c = 2;
          }
        if(diodes[0].Anode == diodes[2].Cathode)
          {
           trans.b = 2;
           trans.c = 0;
          }
        if(diodes[1].Cathode == diodes[2].Anode)
          {
           trans.b = 1;
           trans.c = 2;
          }
        if(diodes[1].Anode == diodes[2].Cathode)
          {
           trans.b = 2;
           trans.c = 1;
          }
#if DebugOut == 4
	Line3();
        lcd_ziff(diodes[0].Anode);
        lcd_data(':');
        lcd_ziff(diodes[0].Cathode);
        lcd_data(' ');
        lcd_string(utoa(diodes[0].Voltage, outval, 10));
        lcd_data(' ');
        lcd_ziff(diodes[1].Anode);
        lcd_data(':');
        lcd_ziff(diodes[1].Cathode);
        lcd_data(' ');
        lcd_string(utoa(diodes[1].Voltage, outval, 10));
	Line4();
        lcd_ziff(diodes[2].Anode);
        lcd_data(':');
        lcd_ziff(diodes[2].Cathode);
        lcd_data(' ');
        lcd_string(utoa(diodes[2].Voltage, outval, 10));
        Line1();
#endif
        if((trans.b<3) && (trans.c<3))
          {
           lcd_data('3');
           lcd_pgm_string(Dioden);	//"Dioden "
           lcd_ziff(diodes[trans.b].Anode);
           lcd_pgm_string(AnKat);	//"->|-"
           lcd_ziff(diodes[trans.b].Cathode);
           lcd_pgm_string(AnKat);	//"->|-"
           lcd_ziff(diodes[trans.c].Cathode);
           UfAusgabe( (trans.b<<4)|trans.c);
           goto end;
          }
       }
    }  // end (PartFound == PART_DIODE)
  else if (PartFound == PART_TRANSISTOR)
    {
    if(PartReady == 0)
      {	//Wenn 2. Pr�fung nie gemacht, z.B. bei Transistor mit Schutzdiode
       trans.hfe[1] = trans.hfe[0];
      }
    if((trans.hfe[0]>trans.hfe[1]))
      {	//Wenn der Verst�rkungsfaktor beim ersten Test h�her war: C und E vertauschen!
       trans.hfe[1] = trans.hfe[0];
       tmp = trans.c;
       trans.c = trans.e;
       trans.e = tmp;
      }

    if(PartMode == PART_MODE_NPN)
      {
       lcd_pgm_string(NPN);		//"NPN "
      }
    else
      {
       lcd_pgm_string(PNP);		//"PNP "
      }
    if(NumOfDiodes > 2)
      {	//Transistor mit Schutzdiode
       if(PartMode == PART_MODE_NPN) lcd_pgm_string(AnKat);	//"->|-"
       else                          lcd_pgm_string(KatAn);	//"-|<-"
      }
    lcd_pgm_string(ebcstr);		//" EBC="
    lcd_ziff(trans.e);
    lcd_ziff(trans.b);
    lcd_ziff(trans.c);
    Line2(); //2. Zeile
    //Verst�rkungsfaktor berechnen
    //hFE = Emitterstrom / Basisstrom
//    if(trans.uBE[1] < 53) trans.uBE[1] = 53;

// #ifdef LONG_HFE
//    lhfe = ((unsigned int)trans.hfe[1] * (unsigned long)(((unsigned long)R_H_VAL * 100) / (unsigned int)(R_L_VAL+PIN_R))) / (unsigned int)trans.uBE[1];	
// #else
//    lhfe = trans.hfe[1] * (R_H_VAL/4) / (((R_L_VAL+PIN_R)/40) * (trans.uBE[1]/10));
// #endif
//    trans.hfe[1] = (unsigned int) lhfe;
    lcd_pgm_string(hfestr);		//"hFE="
    lcd_string(utoa(trans.hfe[1], outval, 10));
    lcd_data(' ');

    for(trans.c=0;trans.c<NumOfDiodes;trans.c++)
      {
       if(((diodes[trans.c].Cathode == trans.e) && (diodes[trans.c].Anode == trans.b) && (PartMode == PART_MODE_NPN)) ||
          ((diodes[trans.c].Anode == trans.e) && (diodes[trans.c].Cathode == trans.b) && (PartMode == PART_MODE_PNP)))
         {
          lcd_pgm_string(Uf);		//"Uf="
          lcd_string(utoa(diodes[trans.c].Voltage, outval, 10));
          lcd_data('m');
          lcd_data('V');
          goto end;
         }
      }
    goto end;
   } // end (PartFound == PART_TRANSISTOR)
 else if (PartFound == PART_FET) 
   {	//JFET oder MOSFET
    if(PartMode&1)
      {	//N-Kanal
       lcd_data('N');
      }
    else
      {
       lcd_data('P');			//P-Kanal
      }
    lcd_data('-');
    if((PartMode==PART_MODE_N_D_MOS) || (PartMode==PART_MODE_P_D_MOS))
      {
       lcd_data('D');			// N-D
       lcd_pgm_string(mosfet);		//"-MOS"
      }
    else
      {
       if((PartMode==PART_MODE_N_JFET) || (PartMode==PART_MODE_P_JFET))
         {
          lcd_pgm_string(jfet);		//"-JFET"
         }
       else
         {
          lcd_data('E');		// -E
          lcd_pgm_string(mosfet);	//"-MOS"
         }
      }
 #ifdef C_MESS	//Gatekapazit�t
    if(PartMode < 3)
      {  //Anreicherungs-MOSFET
       lcd_pgm_string(GateCap);		//" C="
       ReadCapacity(trans.b,trans.e);	//Messung
       trans.hfe[0] = (unsigned int)cval;
//     if(trans.hfe[0]>2) trans.hfe[0] -= 3;
       utoa(trans.hfe[0], outval2, 10);

       lcd_show_format_cap(outval2);
      }
 #endif
    Line2(); //2. Zeile
    lcd_pgm_string(gds);		//"GDS="
    lcd_ziff(trans.b);
    lcd_ziff(trans.c);
    lcd_ziff(trans.e);
    if((NumOfDiodes > 0) && (PartMode < 3))
      {	//MOSFET mit Schutzdiode; gibt es nur bei Anreicherungs-FETs
       lcd_data(LCD_CHAR_DIODE);	//Diode anzeigen
      }
    else
      {
       lcd_data(' ');	//Leerzeichen
      }
    if(PartMode < 3)
      {	//Anreicherungs-MOSFET
       lcd_pgm_string(vt);
       lcd_string(utoa(gthvoltage, outval, 10));	//Gate-Schwellspannung, wurde zuvor ermittelt
       lcd_data('m');
      }
    goto end;
   } // end (PartFound == PART_FET)
 else if (PartFound == PART_THYRISTOR)
   {
    lcd_pgm_string(Thyristor);		//"Thyristor"
    goto gakAusgabe;
   }
 else if (PartFound == PART_TRIAC)
   {
    lcd_pgm_string(Triac);		//"Triac"
    goto gakAusgabe;
   }
 #ifdef R_MESS	//Widerstandsmessung nur mit Mega8 verf�gbar
 else if(PartFound == PART_RESISTOR)
   {
    lcd_pgm_string(Resistor); 		//"Widerst: "
    if (NumOfR == 1)
      { // Einzelwiderstand
       lcd_ziff(resis[ii].rb);  	//Pin-Angabe
       lcd_data(':');
       lcd_ziff(resis[ii].ra);		//Pin-Angaben
      }
    else
      { // R-Max suchen
       ii = 0;
       if ((resis[1].rx * resis[1].kfl) > (resis[0].rx * resis[0].kfl)) ii = 1;
       if (NumOfR == 2)
         {
          ii=2;
         }
       else
         {
          if ((resis[2].rx * resis[2].kfl) > (resis[ii].rx * resis[ii].kfl)) ii = 2;
         }

       if (ii == 0) lcd_pgm_string(T132);	//"1:3:2"
       if (ii == 1) lcd_pgm_string(T123);	//"1:2:3"
       if (ii == 2) lcd_pgm_string(T213);	//"2:1:3"
      }
    Line2(); //2. Zeile
    if (NumOfR == 1)
      { RvalOut(0); }
    else
      {
       if (ii == 0)
         {
          RvalOut(1);
          RvalOut(2);
         }
       if (ii == 1)
         {
          RvalOut(0);
          RvalOut(2);
         }
       if (ii == 2)
         {
          RvalOut(0);
          RvalOut(1);
         }
      }
    goto end;

   } // end (PartFound == PART_RESISTOR)
 #endif

 #ifdef C_MESS
 else if(PartFound == PART_CAPACITOR)
   {	//Kapazit�tsmessung auch nur auf Mega8 verf�gbar
    lcd_pgm_string(Capacitor);
    lcd_ziff(ca);			//Pin-Angaben
    lcd_data('-');
    lcd_ziff(cb);
    Line2(); 				//2. Zeile
    while(cval > 99999)
      {	//ab 100nF oder 100�F
       cval /= 1000;
       cpre++;
      }
    ultoa(cval, outval, 10);
    lcd_show_format_cap(outval);
    lcd_data('F');
    goto end;
   }
 #endif
 if(NumOfDiodes == 0)
   { //Keine Dioden gefunden
    lcd_pgm_string(TestFailed1); 	//"Kein,unbek. oder"
    Line2(); //2. Zeile
    lcd_pgm_string(TestFailed2); 	//"defektes "
    lcd_pgm_string(Bauteil);		//"Bauteil"
   }
 else
   {
    lcd_pgm_string(Bauteil);		//"Bauteil"
    lcd_pgm_string(Unknown); 		//" unbek."
    Line2(); //2. Zeile
    lcd_pgm_string(OrBroken); 		//"oder defekt "
    lcd_data(NumOfDiodes + 48);
    lcd_pgm_string(AnKat);		//"->|-"
   }
  goto end;


gakAusgabe:
    Line2(); //2. Zeile
    lcd_pgm_string(GAK);		//"GAK="
    lcd_ziff(trans.b);
    lcd_ziff(trans.c);
    lcd_ziff(trans.e);
//- - - - - - - - - - - - - - - - - - - - - - - - - - - - 
  end:
  while(!(ON_PIN_REG & (1<<RST_PIN)));	//warten ,bis Taster losgelassen
  wait200ms();
// 10 Sekunden warten
  for(gthvoltage = 0;gthvoltage<10000;gthvoltage++)
    {
     if(!(ON_PIN_REG & (1<<RST_PIN)))
       { /*Wenn der Taster wieder gedr�ckt wurde...
           wieder zum Anfang springen und neuen Test durchf�hren
         */
        goto start;
       }
     wdt_reset();
     wait1ms();
    }
  wdt_disable();			//Watchdog aus
  ON_PORT &= ~(1<<ON_PIN);		//Abschalten
  //Endlosschleife
  while(1)
    {
     if(!(ON_PIN_REG & (1<<RST_PIN)))
       {  /* wird nur erreicht,
         wenn die automatische Abschaltung nicht eingebaut wurde */
        goto start;
       }
    }
  return 0;
}   // end main

//******************************************************************
// Ausgabe der Flussspannung f�r 1-2 Dioden in Zeile 2
// bcdnum = Nummern der beiden Dioden:
// oberer 4 Bit  Index der ersten Diode
// untere 4 Bit  Index der zweiten Diode (Struktur diodes[nn])
// wenn Index >= 3 erfolgt keine Ausgabe
void UfAusgabe(uint8_t bcdnum)
{
   uint8_t nn;

   Line2(); 				//2. Zeile
   lcd_pgm_string(Uf);			//"Uf="
   nn = (bcdnum >> 4);
   if (nn < 3)
     {
      lcd_string(utoa(diodes[nn].Voltage, outval, 10));
      lcd_data('m');
      lcd_data('V');
      lcd_data(' ');
     }
   nn = (bcdnum & 0x0f);
   if (nn < 3)
     {
      lcd_string(utoa(diodes[nn].Voltage, outval, 10));
      lcd_data('m');
      lcd_data('V');
     }
}

#ifdef R_MESS
void RvalOut(uint8_t ii)		// Widerstandswert ausgeben
  {
   uint8_t strlength;
   uint8_t CommaPos;

   ultoa(resis[ii].rx,outval,10);
   strlength = strlen(outval);

   if(resis[ii].kfl==100)
     {  //470k-Widerstand?
      strlength = strlen(outval);	//N�tig, um Komma anzuzeigen
      ca = strlength;
      if (strlength < 5)
        {
         CommaPos = strlength-2;
        }
      else
        {
         CommaPos = strlength-5;	// Ausgabe in MOhm
         ca = CommaPos + 3;
         if (strlength > 5) ca = CommaPos + 2;
        }
      for(cb=0;cb<ca;cb++)
        {
         lcd_data(outval[cb]);
         if(cb==CommaPos) lcd_data('.'); //Komma
        }
      if (strlength < 5)
        lcd_data ('k'); //Kilo-Ohm, falls 470k-Widerstand verwendet
      else
        lcd_data ('M'); //Mega-Ohm, falls 470k-Widerstand verwendet
     }
   else
     {
      strlength = strlen(outval);	//N�tig, um Komma anzuzeigen
      if (strlength < 4)
        {
         lcd_string(outval);
        }
      else
        {
         CommaPos = strlength - 4;
         ca = strlength-1;
         if (ca > 3) ca = strlength-2;
      
         for(cb=0;cb<ca;cb++)
           {
            lcd_data(outval[cb]);
            if(cb==CommaPos) lcd_data('.');	//Komma
           }
           lcd_data ('k'); 	//Kilo-Ohm
        }
     }
   lcd_data(LCD_CHAR_OMEGA);	//Omega f�r Ohm 
   lcd_data(' ');
  }
#endif

//******************************************************************
#include "CheckPins.c"


void ChargePin10ms(uint8_t PinToCharge, uint8_t ChargeDirection)
  { //Anschluss eines Bauelementes kurz(10ms) auf ein bestimmtes Potenzial legen
    //Diese Funktion ist zum Entladen von MOSFET-Gates vorgesehen, um Schutzdioden u.�. in MOSFETs
    //erkennen zu k�nnen
    //Parameter:
    //PinToCharge: zu entladender Pin als Bits f�r den R-Port
    //ChargeDirection: 0 = gegen Masse (N-Kanal-FET), 1= gegen Plus(P-Kanal-FET)

   if(ChargeDirection&1) R_PORT |= PinToCharge;	//R_PORT auf 1 (VCC) 
   else                  R_PORT &= ~PinToCharge; // oder 0 (GND)
   R_DDR |= PinToCharge;			//Pin auf Ausgang, �ber R auf Masse oder VCC
   wait10ms();
   // hochohmig schalten, Input
   R_DDR &= ~PinToCharge;	// R f�r Pin wieder auf Eingang
   R_PORT &= ~PinToCharge;	// kein Pullup
  }

// erst vorhandene Restladung entladen
void EntladePins()
 {
  uint8_t adc_gnd;		// Maske der ADC-Ausg�nge, die direkt auf GND gelegt werden
  unsigned int adcmv[3];	// Spannungswerte der 3 Pins in mV

  adc_gnd = TXD_MSK;		// alle ADC auf Input
  ADC_DDR = adc_gnd;
  ADC_PORT = TXD_VAL;		// ADC-Ausg�nge auf 0 (kein Pullup)
  R_PORT = 0;			// R-Ausg�nge auf 0
  R_DDR = (2<<(PC2*2)) | (2<<(PC1*2)) | (2<<(PC0*2)); // alle Pins �ber R_H auf Masse
  adcmv[0] = W5msReadADC(PC0);	// welche Spannung hat Pin 1?
  adcmv[1] = ReadADC(PC1);	// welche Spannung hat Pin 2?
  adcmv[2] = ReadADC(PC2);	// welche Spannung hat Pin 3?
  // alle Pins mit weniger als 1V direkt �ber ADC-Port auf Masse (GND) schalten
  if (adcmv[0] < 1000) adc_gnd |= (1<<PC0);	//Pin 1 �ber Ausgang des Analog-Pins auf GND
  if (adcmv[1] < 1000) adc_gnd |= (1<<PC1);	//Pin 2 �ber Ausgang des Analog-Pins auf GND
  if (adcmv[2] < 1000) adc_gnd |= (1<<PC2);	//Pin 3 �ber Ausgang des Analog-Pins auf GND
  ADC_DDR = adc_gnd;		// jetzt alle gew�hlten ADC-Ports auf GND schalten

  // zus�tzlich die verbleibenden Ports �ber R_L auf Masse.
  // Da es bei den direkt auf Masse geschalteten Pins auch nicht schadet, werden
  // einfach alle R_L Widerst�nde geschaltet
  R_DDR = (1<<(PC0*2)) | (1<<(PC1*2)) | (1<<(PC2*2));	// Pins �ber R_L Widerst�nde auf GND
  while(1)
    {
     wdt_reset();
     adcmv[0] = W5msReadADC(PC0);	// welche Spannung hat Pin 1?
     adcmv[1] = ReadADC(PC1);	// welche Spannung hat Pin 2?
     adcmv[2] = ReadADC(PC2);	// welche Spannung hat Pin 3?
     if (adcmv[0] < 1300) ADC_DDR |= (1<<PC0);	// unter 1.3V �ber ADC-Port auf GND
     if (adcmv[1] < 1300) ADC_DDR |= (1<<PC1);	// unter 1.3V �ber ADC-Port auf GND
     if (adcmv[2] < 1300) ADC_DDR |= (1<<PC2);	// unter 1.3V �ber ADC-Port auf GND
     if ((adcmv[0] < 5) && (adcmv[1] < 5) && (adcmv[2] < 5)) break;
    }
  wait200ms();			// noch 200ms im Kurzschluss-Mode
  ADC_DDR = TXD_MSK;		// alle direkten ADC-Ausg�nge hochohmig
  R_DDR = 0;			// alle R_L Ports (und R_H) hochohmig
 }

#ifdef DebugOut

void lcd_clear_line(void)
{
 unsigned char ll;
 for (ll=0;ll<18;ll++) lcd_data(' ');
}

#endif

#ifdef C_MESS	//Kapazit�tsmessung nur auf Mega8 verf�gbar
#include "ReadCapacity.c"


void lcd_show_format_cap(char outval[])
  {
  uint8_t strlength;
  uint8_t CommaPos;
  strlength = strlen(outval);
  CommaPos = strlength-3;
  if(strlength < 5)
    {
       lcd_string(outval);
    }
  else
    { // letzte Stelle weglassen, aus pF nF, aus nF �F, aus �F mF
     cpre++;
     for(PartReady=0;PartReady<(strlength-1);PartReady++)
       { // letzte Stelle weglassen
        if(PartReady == CommaPos) lcd_data('.');
        lcd_data(outval[PartReady]);
       }
    }
  tmpval2 = pgm_read_byte(&C_Prefix_tab[cpre]);
  lcd_data(tmpval2);		// n oder � oder m
 }
#endif
