// Definitionen der Warteschleifen
void wait1000ms();
void wait500ms();
void wait300ms();
void wait200ms();
void wait100ms();
void wait50ms();
void wait30ms();
void wait20ms();
void wait10ms();
void wait5ms();
void wait3ms();
void wait2ms();
void wait1ms();
void wait500us();
void wait300us();
void wait200us();
void wait100us();
void wait50us();
void wait30us();
void wait20us();
void wait10us();

