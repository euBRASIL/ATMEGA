/*	Sprache
	GERMAN = deutsch
	ENGLISH = englisch
	POLISH = polnisch
	CZECH = tschechisch
	SLOVAK = slowakisch
*/
#define GERMAN

/*	LCD-Modus
	Wird LCD_CYRILLIC definiert, dann wird das Omega- und �-Zeichen als "Custom Character" erzeugt.
	Das ist n�tig, weil HD44780 mit einem anderen als dem "Standard-Zeichensatz"
	diese Zeichen nicht in ihrem ROM enthalten.
*/
//#define LCD_CYRILLIC

/*
Mit dem Define SWUART_INVERT kann festgelegt werden, ob der Software-UART normal oder invertiert sendet.
In der normalen Betriebsart sendet der UART in der �blichen Logik (Low = 0; High = 1).
Das ist der Standardfall und dient zum Anschluss an einen anderen �C, einen USB=>Seriell-Wandler-Chip
oder an einen Pegelwandler wie den MAX232.

In der invertierten Betriebsart sendet der UART in umgekehrter Logik, also High = 0 und Low = 1
Das entspricht der Logik der RS232-Schnittstelle von Standard-PCs.
In den meisten F�llen kann der TxD des Software-UART somit direkt mit dem RxD des PCs verbunden werden.
Laut Spezifikation ist das unzul�ssig, weil f�r eine RS232-Schnittstelle Pegel von -3V...3V undefiniert sind.
An den meisten PCs funktioniert es aber trotzdem ohne Probleme.
Das ist eine einfache, aber etwas unsaubere L�sung...

Ist SWUART_INVERT definiert, arbeitet der UART in invertierter Betriebsart.
*/
//#define SWUART_INVERT

#define TxD PC3	//TxD-Pin des Software-UART; muss an Port C sein!


//AVR-Typenabh�nggikeit
#if defined(__AVR_ATmega48__)
  #define MCU_STATUS_REG MCUCR
#elif defined(__AVR_ATmega88__)
  #define MCU_STATUS_REG MCUCR
  #define UseM8
#elif defined(__AVR_ATmega168__)
  #define MCU_STATUS_REG MCUCR
  #define UseM8
#else
  #define MCU_STATUS_REG MCUCSR
  #define UseM8
#endif


// UseM8 wird nur hier abgefragt, die Programme fragen �ber Preprozessor 
// die "defines"  R_MESS, C_MESS, LONG_HFE und WITH_UART ab
#ifdef UseM8
// R_MESS aktiviert die Widerstands-Messung
#define R_MESS
// C_MESS aktiviert die Kapazit�ts-Messung
#define C_MESS
// KOLLEKTOR_SCHALTUNG aktiviert Stromverst�rkungs-Messung auch in Kollektorschaltung (Emitterfolger)
#define KOLLEKTOR_SCHALTUNG
// LONG_HFE  aktiviert die Berechnung der Stromverst�rkungs-Faktor mit long Variablen
#define LONG_HFE
// WITH_UART aktiviert die Ausgabe auf einem Software-UART
#define WITH_UART
#endif

