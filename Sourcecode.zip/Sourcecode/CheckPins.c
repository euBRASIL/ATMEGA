//******************************************************************
void CheckPins(uint8_t HighPin, uint8_t LowPin, uint8_t TristatePin)
  {
  /*
  Funktion zum Testen der Eigenschaften des Bauteils bei der angegebenen Pin-Belegung
  Parameter:
  HighPin: Pin, der anfangs auf positives Potenzial gelegt wird
  LowPin: Pin, der anfangs auf negatives Potenzial gelegt wird
  TristatePin: Pin, der anfangs offen gelassen wird

  Im Testverlauf wird TristatePin nat�rlich auch positiv oder negativ geschaltet.
*/
  struct {
  unsigned int lp_otr;
  unsigned int hp1;
  unsigned int hp2;
  unsigned int hp3;
  unsigned int lp1;
  unsigned int lp2;
  unsigned int tp1;
  unsigned int tp2;
  }adc;
  uint8_t LoPinRL, LoPinRH;	// Schaltbefehl f�r LowPin R_L / R_H
  uint8_t TriPinRL, TriPinRH;	// Schaltbefehl f�r TristatePin R_L / R_H
  uint8_t HiPinRL, HiPinRH;	// Schaltbefehl f�r HighPin R_L / R_H
  uint8_t HiADC, LoADC;
  uint8_t ii;

#ifdef R_MESS
  struct resis_t *thisR;
  unsigned long lrx1;
  unsigned long llrx1;
  unsigned long llrx2;
  uint8_t kflag;
#endif
  /*
    HighPin wird fest auf Vcc gelegt
    LowPin wird �ber R_L auf GND gelegt
    TristatePin wird hochohmig geschaltet, daf�r ist keine Aktion n�tig
  */
  wdt_reset();
  LoPinRL = pgm_read_byte(&PinRLtab[LowPin]);		// Schaltbefehl f�r LowPin R_L
  LoPinRH = LoPinRL + LoPinRL;				// Schaltbefehl for LowPin R_H
  TriPinRL = pgm_read_byte(&PinRLtab[TristatePin]);	// Schaltbefehl f�r TristatePin R_L
  TriPinRH = TriPinRL + TriPinRL;			// Schaltbefehl f�r TristatePin R_H
  HiPinRL = pgm_read_byte(&PinRLtab[HighPin]);		// Schaltbefehl f�r HighPin R_L
  HiPinRH = HiPinRL + HiPinRL;				// Schaltbefehl f�r HighPin R_H

  HiADC = pgm_read_byte(&PinADCtab[HighPin]);
  LoADC = pgm_read_byte(&PinADCtab[LowPin]);

  //Pins setzen
  R_PORT = 0;
  R_DDR = LoPinRL;			//Low-Pin auf Ausgang und �ber R_L auf Masse
  ADC_DDR = HiADC | TXD_MSK;		//High-Pin auf Ausgang
  ADC_PORT = HiADC | TXD_VAL;		//High-Pin fest auf Vcc
  //Bei manchen MOSFETs muss das Gate (TristatePin) zuerst entladen werden
  ChargePin10ms(TriPinRL,0);		//entladen f�r N-Kanal
  adc.lp_otr = W5msReadADC(LowPin);	//Spannung am Low-Pin ermitteln
  if(adc.lp_otr >= 977) 		//Sperrt das Bauteil jetzt?
    {
     ChargePin10ms(TriPinRL,1);	 	//sonst: Entladen f�r P-Kanal (Gate auf Plus)
     adc.lp_otr = ReadADC(LowPin);	//Spannung am Low-Pin erneut ermitteln
    }

#if DebugOut == 5
  Line2();
  lcd_clear_line();
  Line2();
#endif

  if(adc.lp_otr > 92)
    {  //Bauteil leitet ohne Steuerstrom etwas
#if DebugOut == 5
     lcd_ziff(LowPin);
     lcd_data('F');
     lcd_ziff(HighPin);
     lcd_data(' ');
     wait1000ms();
#endif
     //Test auf N-JFET oder selbstleitenden N-MOSFET
     R_DDR = LoPinRL | TriPinRH;	//Tristate-Pin (vermutetes Gate) �ber R_H auf Masse
     adc.lp1 = W20msReadADC(LowPin);	//Spannung am vermuteten Source messen
     R_PORT = TriPinRH;			//Tristate-Pin (vermutetes Gate) �ber R_H auf Plus
     adc.lp2 = W20msReadADC(LowPin);	//Spannung am vermuteten Source erneut messen
     //Wenn es sich um einen selbstleitenden MOSFET oder JFET handelt, m�sste adc.lp1 > adc.lp_otr sein
     if(adc.lp2>(adc.lp1+488))
       { //Spannung am Gate messen, zur Unterscheidung zwischen MOSFET und JFET
        ADC_PORT = TXD_VAL;
        ADC_DDR = LoADC | TXD_MSK;	//Low-Pin fest auf Masse
        R_DDR = TriPinRH | HiPinRL;	//High-Pin auf Ausgang
        R_PORT = TriPinRH | HiPinRL;	//High-Pin �ber R_L auf Vcc
        adc.lp2 = W20msReadADC(TristatePin); //Spannung am vermuteten Gate messen
        if(adc.lp2>3911) 
          {  //MOSFET
           PartFound = PART_FET;	//N-Kanal-MOSFET
           PartMode = PART_MODE_N_D_MOS; //Verarmungs-MOSFET
          }
        else 
          {  //JFET (pn-�bergang zwischen G und S leitet)
           PartFound = PART_FET;	//N-Kanal-JFET
           PartMode = PART_MODE_N_JFET;
          }
        trans.b = TristatePin;
        trans.c = HighPin;
        trans.e = LowPin;
       }

     ADC_PORT = TXD_VAL;		// direkte Ausg�nge auf Masse

     //Test auf P-JFET oder selbstleitenden P-MOSFET
     ADC_DDR = LoADC | TXD_MSK;		//Low-Pin (vermuteter Drain) fest auf Masse,
					//Tristate-Pin (vermutetes Gate) ist noch �ber R_H auf Plus
     R_DDR = TriPinRH | HiPinRL;	//High-Pin auf Ausgang
     R_PORT = TriPinRH | HiPinRL;	//High-Pin �ber R_L auf Vcc
     adc.hp1 = W20msReadADC(HighPin);	//Spannung am vermuteten Source messen
     R_PORT = HiPinRL;			//Tristate-Pin (vermutetes Gate) �ber R_H auf Masse
     adc.hp2 = W20msReadADC(HighPin);	//Spannung am vermuteten Source erneut messen
     //Wenn es sich um einen selbstleitenden P-MOSFET oder P-JFET handelt, m�sste adc.hp1 > adc.hp2 sein
     if(adc.hp1>(adc.hp2+488))
       { //Spannung am Gate messen, zur Unterscheidung zwischen MOSFET und JFET
        ADC_PORT = HiADC | TXD_VAL;	//High-Pin fest auf Plus
        ADC_DDR = HiADC | TXD_MSK;	//High-Pin auf Ausgang
        adc.tp2 = W20msReadADC(TristatePin); //Spannung am vermuteten Gate messen
        if(adc.tp2<977)
          {  //MOSFET
           PartFound = PART_FET;	//P-Kanal-MOSFET
           PartMode = PART_MODE_P_D_MOS; //Verarmungs-MOSFET
          }
        else
          {  //JFET (pn-�bergang zwischen G und S leitet)
           PartFound = PART_FET;	//P-Kanal-JFET
           PartMode = PART_MODE_P_JFET;
          }
        trans.b = TristatePin;
        trans.c = LowPin;
        trans.e = HighPin;
      }
   } // end Bauteil leitet etwas ohne Steuerstrom


#ifdef KOLLEKTOR_SCHALTUNG
  // Test Kollektorschaltung (Emitterfolger)
  ADC_PORT = TXD_VAL;
  ADC_DDR = LoADC;			// Kollektor direkt auf GND
  R_PORT = HiPinRL;			// Emitter �ber Widerstand R_L auf VCC
  R_DDR = TriPinRL | HiPinRL;		// Basiswiderstand R_L auf GND
  adc.hp1 = U_VCC - W5msReadADC(LowPin);	// Spannung am Emitterwiderstand
  adc.tp1 = ReadADC(TristatePin);	// BasiswiderstandsSpannung
#endif

  //Pins erneut setzen f�r Emitterschaltung
  R_DDR = LoPinRL;			//Low-Pin auf Ausgang und �ber R_L auf Masse
  R_PORT = 0;
  ADC_DDR = HiADC | TXD_MSK;		//High-Pin auf Ausgang
  ADC_PORT = HiADC | TXD_VAL;		//High-Pin fest auf Vcc
  wait5ms();
  
  if(adc.lp_otr < 977)
    {  //Wenn das Bauteil keinen Durchgang zwischen HighPin und LowPin hat
#if DebugOut == 5
     lcd_ziff(LowPin);
     lcd_data('P');
     lcd_ziff(HighPin);
     lcd_data(' ');
     wait1000ms();
#endif
     //Test auf pnp
     R_DDR = LoPinRL | TriPinRL;	//Tristate-Pin �ber R_L auf Masse, zum Test auf pnp
     adc.lp1 = W5msReadADC(LowPin);		//Spannung messen
     if(adc.lp1 > 3422)
       { //Bauteil leitet => pnp-Transistor o.�.
        //Verst�rkungsfaktor in beide Richtungen messen
        R_DDR = LoPinRL | TriPinRH;	//Tristate-Pin (Basis) �ber R_H auf Masse

        adc.lp1 = W5msReadADC(LowPin);	//Spannung am Low-Pin (vermuteter Kollektor) messen
        adc.tp2 = ReadADC(TristatePin);	//Basisspannung messen
        //Pr�fen, ob Test schon mal gelaufen
        if((PartFound == PART_TRANSISTOR) || (PartFound == PART_FET)) PartReady = 1;

#ifdef KOLLEKTOR_SCHALTUNG
        if (adc.tp1 < 150)
          { 
#endif
            //Verst�rkungsfaktor berechnen Emitterschaltung
            //hFE = Kollektorstrom / Basisstrom
            adc.tp1 = adc.tp2;
            if(adc.tp1 < 53) adc.tp1 = 53;

 #ifdef LONG_HFE
            lhfe = ((unsigned int)adc.lp1 * (unsigned long)(((unsigned long)R_H_VAL * 100) / 
                    (unsigned int)(R_L_VAL+PIN_R))) / (unsigned int)adc.tp1;	
            trans.hfe[PartReady] = (unsigned int) lhfe;
 #else
            trans.hfe[PartReady] = ((adc.lp1 / ((R_L_VAL+PIN_R)/100)) * (R_H_VAL/50)) / (adc.tp1/50);
 #endif
#ifdef KOLLEKTOR_SCHALTUNG
           }
        else
           { //Verst�rkungsfaktor Kollektorschaltung (Emitterfolger)
             // hFE = (Emitterstrom - Basisstrom) / Basisstrom
            trans.hfe[PartReady] = (adc.hp1 - adc.tp1) / adc.tp1;
           }
#endif

 
        if(PartFound != PART_THYRISTOR)
          {
           if(adc.tp2 > 977)
             {
              PartFound = PART_TRANSISTOR;	//PNP-Transistor gefunden (Basis wird "nach oben" gezogen)
              PartMode = PART_MODE_PNP;
             }
           else
             {
              if((adc.lp_otr < 97) && (adc.lp1 > 2000))
                {  //Durchlassspannung im gesperrten Zustand gering genug?
                   //(sonst werden D-Mode-FETs f�lschlicherweise als E-Mode erkannt)
        	 PartFound = PART_FET;		//P-Kanal-MOSFET gefunden (Basis/Gate wird NICHT "nach oben" gezogen)
        	 PartMode = PART_MODE_P_E_MOS;
        	 //Messung der Gate-Schwellspannung
        	 ADMUX = TristatePin | (1<<REFS0);	// switch to TristatePin, Ref. VCC
        	 gthvoltage = 0;
        	 for(ii=0;ii<11;ii++)
                   {
        	    wdt_reset();
        	    ChargePin10ms(TriPinRL,1);
                    R_DDR = LoPinRL | TriPinRH;	//Tristate-Pin (Basis) �ber R_H auf Masse
        	    while (!(ADC_PIN&LoADC));  // Warten, bis der MOSFET schaltet und Drain auf high geht
        	    R_DDR = LoPinRL;
        	    ADCSRA |= (1<<ADSC);	// Start Conversion
        	    while (ADCSRA&(1<<ADSC));	// wait
      		    gthvoltage += (U_VCC - ADCW); // Add Tristatepin-Voltage
                   }
                 gthvoltage *= 4;		// entspricht 44*ADCW
                 gthvoltage /= 9;		// umrechnen in mV
                }
             }
           trans.b = TristatePin;
           trans.c = LowPin;
           trans.e = HighPin;
          }  // end if PartFound != Part_THYRISTOR
      } // end Bauteil leitet => pnp

#ifdef KOLLEKTOR_SCHALTUNG
    // Low-Pin=RL- HighPin=VCC
    R_DDR = LoPinRL | TriPinRL;
    R_PORT = TriPinRL;			// TriPin=RL+  Kollektorschaltung NPN
    adc.lp1 = W5msReadADC(LowPin);	// Spannung am Emitterwiderstand
    adc.tp1 = ReadADC(TristatePin);	// Spannung der Basis
#endif
    //Tristate (vermutete Basis) auf Plus, zum Test auf npn
    ADC_DDR = LoADC | TXD_MSK;		//Low-Pin auf Ausgang 0V
    ADC_PORT = TXD_VAL;			//Low-Pin fest auf Masse
    R_DDR = TriPinRL | HiPinRL;		//High-Pin und Tristate-Pin auf Ausgang
    R_PORT = TriPinRL | HiPinRL;	//High-Pin und Tristate-Pin �ber R_L auf Vcc
    adc.hp1 = W5msReadADC(HighPin);	//Spannung am High-Pin messen
    if(adc.hp1 < 1600)
      { //Bauteil leitet => npn-Transistor o.�.
#if DebugOut == 5
       lcd_ziff(LowPin);
       lcd_data('N');
       lcd_ziff(HighPin);
       lcd_data(' ');
       wait1000ms();
#endif
       if(PartReady==1) goto testend;

       //Test auf Thyristor:
       //Gate entladen
       ChargePin10ms(TriPinRL,0);	//Tristate-Pin (Gate) �ber R_L 10ms auf Masse
       adc.hp3 = W5msReadADC(HighPin);	//Spannung am High-Pin (vermutete Anode) erneut messen
					//Strom soll weiterflie�en, falls nicht,
					// kein Thyristor oder Haltestrom zu niedrig
		 	
       R_PORT = 0;			//High-Pin (vermutete Anode) auf Masse (l�schen)
       wait5ms();
       R_PORT = HiPinRL;		//High-Pin (vermutete Anode) wieder auf Plus
       adc.hp2 = W5msReadADC(HighPin);	//Spannung am High-Pin (vermutete Anode) erneut messen
#if DebugOut == 5
       Line3();
       lcd_clear_line();
       Line3();
       lcd_data('T');
       lcd_data('0');
       lcd_data('h');
       lcd_string(utoa(adc.hp3,outval,10));
       lcd_data(' ');
       lcd_data('H');
       lcd_data('0');
       lcd_data('h');
       lcd_string(utoa(adc.hp2,outval,10));
       wait1000ms();
       wait1000ms();
#endif
       if((adc.hp3 < 1600) && (adc.hp2 > 4400))
         {  //Nach Abschalten des Haltestroms muss der Thyristor sperren
          //war vor Abschaltung des Triggerstroms geschaltet und ist immer noch geschaltet obwohl Gate aus => Thyristor
          PartFound = PART_THYRISTOR;
          //Test auf Triac
          R_DDR = 0;
          R_PORT = 0;
          ADC_PORT = LoADC | TXD_VAL;	//Low-Pin fest auf Plus
          wait5ms();
          R_DDR = HiPinRL;		//HighPin �ber R_L auf Masse
          if(W5msReadADC(HighPin) > 244)
             goto savenresult;	//Spannung am High-Pin (vermuteter A2) messen; falls zu hoch:
                                //Bauteil leitet jetzt => kein Triac
          R_DDR = HiPinRL | TriPinRL;	//Gate auch �ber R_L auf Masse => Triac m�sste z�nden
         if(W5msReadADC(TristatePin) < 977)
            goto savenresult; //Spannung am Tristate-Pin (vermutetes Gate) messen;
                              // Abbruch falls Spannung zu gering
         if(ReadADC(HighPin) < 733) goto savenresult; //Bauteil leitet jetzt nicht => kein Triac => Abbruch
         R_DDR = HiPinRL;		//TristatePin (Gate) wieder hochohmig
         if(W5msReadADC(HighPin) < 733)
            goto savenresult; //Bauteil leitet nach Abschalten des Gatestroms nicht mehr=> kein Triac => Abbruch
         R_PORT = HiPinRL;		//HighPin �ber R_L auf Plus => Haltestrom aus
         wait5ms();
         R_PORT = 0;			//HighPin wieder �ber R_L auf Masse; Triac m�sste jetzt sperren
         if(W5msReadADC(HighPin) > 244)
            goto savenresult;	//Spannung am High-Pin (vermuteter A2) messen;
                                //falls zu hoch: Bauteil leitet jetzt => kein Triac
         PartFound = PART_TRIAC;
         PartReady = 1;
         goto savenresult;
        }
      //Test auf Transistor oder MOSFET
      // ADC_DDR = LoADC | TXD_MSK;		//Low-Pin auf Ausgang 0V
      R_DDR = HiPinRL | TriPinRH;	//Tristate-Pin (Basis) auf Ausgang
      R_PORT = HiPinRL | TriPinRH;	//Tristate-Pin (Basis) �ber R_H auf Plus
      wait50ms();
      adc.hp2 = ReadADC(HighPin);	//Spannung am High-Pin (vermuteter Kollektor) messen
      adc.tp2 = ReadADC(TristatePin);	//Basisspannung messen

#if DebugOut == 5
       Line4();
       lcd_clear_line();
       Line4();
       lcd_data('H');
       lcd_data('P');
       lcd_string(utoa(adc.hp2,outval,10));
       lcd_data(' ');
       lcd_data('T');
       lcd_data('P');
       lcd_string(utoa(adc.tp2,outval,10));
       wait1000ms();
       wait1000ms();
#endif
      if((PartFound == PART_TRANSISTOR) || (PartFound == PART_FET)) PartReady = 1;	//pr�fen, ob Test schon mal gelaufen

#ifdef KOLLEKTOR_SCHALTUNG
      if (adc.tp1 > 4900)
        { 
#endif
          //Verst�rkungsfaktor berechnen Emitterschaltung
          //hFE = Kollektorstrom / Basisstrom
         adc.tp1 = U_VCC - adc.tp2;		// Spannung am Basis-Widerstand
         if(adc.tp1 < 53) adc.tp1 = 53;

 #ifdef LONG_HFE
         lhfe = ((unsigned int)(U_VCC - adc.hp2) * (unsigned long)(((unsigned long)R_H_VAL * 100) / 
                 (unsigned int)(R_L_VAL+PIN_R))) / (unsigned int)adc.tp1;	
         trans.hfe[PartReady] = (unsigned int) lhfe;
 #else
         trans.hfe[PartReady] = (((U_VCC - adc.hp2) / ((R_L_VAL+PIN_R)/100)) * (R_H_VAL/50)) / (adc.tp1/50);
 #endif
#ifdef KOLLEKTOR_SCHALTUNG
        }
      else
        { //Verst�rkungsfaktor berechnen Kollektorschaltung (Emitterfolger)
          // hFE = (Emitterstrom - Basisstrom) / Basisstrom
          trans.hfe[PartReady] = (adc.lp1 - (U_VCC - adc.tp1)) / (U_VCC - adc.tp1);
        }
#endif

      if(adc.tp2 < 2444)
        { // Basis-Spannung R_H klein genug
         PartFound = PART_TRANSISTOR;	//NPN-Transistor gefunden (Basis wird "nach unten" gezogen)
         PartMode = PART_MODE_NPN;
        }
      else
        { // Basis zieht kaum Strom
         if((adc.lp_otr < 97) && (adc.hp2 < 1600))
           {  //Durchlassspannung im gesperrten Zustand gering genug?
              //(sonst werden D-Mode-FETs f�lschlicherweise als E-Mode erkannt)
            PartFound = PART_FET;	//N-Kanal-MOSFET gefunden (Basis/Gate wird NICHT "nach unten" gezogen)
            PartMode = PART_MODE_N_E_MOS;
#if DebugOut == 5
            Line3();
            lcd_clear_line();
            Line3();
            lcd_data('N');
            lcd_data('F');
            wait1000ms();
#endif
            //Gate-Schwellspannung messen
            ADMUX = TristatePin | (1<<REFS0);	// messe TristatePin, Ref. VCC
            gthvoltage = 0;
            for(ii=0;ii<11;ii++)
              {
            	wdt_reset();
            	ChargePin10ms(TriPinRL,0);
                R_DDR = HiPinRL | TriPinRH;	// Gate langsam laden
                R_PORT = HiPinRL | TriPinRH;
            	while ((ADC_PIN&HiADC));  // Warten, bis der MOSFET schaltet und Drain auf low geht
                R_DDR = HiPinRL;
            	R_PORT = HiPinRL;
            	ADCSRA |= (1<<ADSC);		// starte Conversion
            	while (ADCSRA&(1<<ADSC));	// warte
            	gthvoltage += ADCW;
#if DebugOut == 5
                lcd_data('.');
#endif
               }
            gthvoltage *= 4;	//entspricht 44 * ADCW
            gthvoltage /= 9;	//umrechnen in mV
           }
        }
savenresult:
      trans.b = TristatePin;		// merke Pin-Konstellation
      trans.c = HighPin;
      trans.e = LowPin;
     } // end Bauteil leitet => npn
    ADC_DDR = TXD_MSK;		// alle ADC-Ports hochohmig
    ADC_PORT = TXD_VAL;		// alls ADC-Ports auf 0 (kein Pullup)
    //Fertig
   } //end das Bauteil hat keinen Durchgang zwischen HighPin und LowPin
 else
   {  // Bauteil hat Durchgang
    //Test auf Diode
    ADC_PORT = TXD_VAL;
    ADC_DDR = LoADC | TXD_MSK;	//Low-Pin fest auf Masse
    R_DDR = HiPinRL;		//High-Pin �ber R_L auf Plus
    R_PORT = HiPinRL;
    ChargePin10ms(TriPinRL,1); //Entladen f�r P-Kanal-MOSFET
    adc.lp_otr = W5msReadADC(HighPin) - ReadADC(LowPin);
    R_DDR = HiPinRH;		//High-Pin �ber R_H auf Plus
    R_PORT = HiPinRH;
    adc.hp2 = W5msReadADC(HighPin); 		// M--|<--HP--R_H--Plus

    R_DDR = HiPinRL;		//High-Pin �ber R_L auf Plus
    R_PORT = HiPinRL;
    ChargePin10ms(TriPinRL,0); //Entladen f�r N-Kanal-MOSFET
    adc.hp1 = W5msReadADC(HighPin) - W5msReadADC(LowPin);
    R_DDR = HiPinRH;		//High-Pin �ber R_H  auf Plus
    R_PORT = HiPinRH;
    adc.hp3 = W5msReadADC(HighPin);		// M--|<--HP--R_H--Plus

    /*Ohne das Entladen kann es zu Falscherkennungen kommen, da das Gate eines MOSFETs noch geladen sein kann.
      Die zus�tzliche Messung mit dem "gro�en" Widerstand R_H wird durchgef�hrt, um antiparallele Dioden von
      Widerst�nden unterscheiden zu k�nnen.
      Eine Diode hat eine vom Durchlassstrom relativ unabh�ngige Durchlassspg.
      Bei einem Widerstand �ndert sich der Spannungsabfall stark (linear) mit dem Strom.
    */
    if(adc.lp_otr > adc.hp1)
      {
       adc.hp1 = adc.lp_otr;	//der h�here Wert gewinnt
       adc.hp3 = adc.hp2;
      }
#if DebugOut == 4
    Line3();
    lcd_clear_line();
    Line3();
    lcd_ziff(HighPin);
    lcd_data('D');
    lcd_ziff(LowPin);
    lcd_data(' ');
    lcd_data('L');
    lcd_string(utoa(adc.hp1,outval,10));
    lcd_data(' ');
    lcd_data('H');
    lcd_string(utoa(adc.hp3,outval,10));
    for(ii=0;ii<6;ii++) wait1000ms();
#endif

    if((adc.hp1 > 150) && (adc.hp1 < 4640) && (adc.hp1 > adc.hp3))
      { //Spannung liegt �ber 0,15V und unter 4,64V => Ok
       if((PartFound == PART_NONE) || (PartFound == PART_RESISTOR))
         PartFound = PART_DIODE;	//Diode nur angeben, wenn noch kein anderes Bauteil gefunden wurde.
					//Sonst g�be es Probleme bei Transistoren mit Schutzdiode
       diodes[NumOfDiodes].Anode = HighPin;
       diodes[NumOfDiodes].Cathode = LowPin;
       diodes[NumOfDiodes].Voltage = adc.hp1;	// Spannung in Millivolt 
       NumOfDiodes++;
       for(ii=0;ii<NumOfDiodes;ii++)
         {
          if((diodes[ii].Anode == LowPin) && (diodes[ii].Cathode == HighPin))
            {  //zwei antiparallele Dioden: Defekt oder Duo-LED
//===========================================================================================
             if((adc.hp3*6) < (adc.hp1 / 53))
           //if((adc.hp3*64) < (adc.hp1 / 5))
//===========================================================================================
               {  //Durchlassspannung f�llt bei geringerem Teststrom stark ab => Defekt
          	if(ii<NumOfDiodes)
                  {
        	   for(uint8_t j=ii;j<(NumOfDiodes-1);j++)
                     {
        	      diodes[j].Anode = diodes[j+1].Anode;
        	      diodes[j].Cathode = diodes[j+1].Cathode;
        	      diodes[j].Voltage = diodes[j+1].Voltage;
        	     }
        	  }
 #if DebugOut == 4
                lcd_data('R');
                lcd_ziff(NumOfDiodes);
 #endif
                NumOfDiodes -= 2;
               }
            }
         } // end for
      } //end Spannung liegt �ber 0,15V und unter 4,64V 
   }  // end Bauteil hat Durchgang zwischen High und Low Pin

#ifdef R_MESS	//Widerstandsmessung nur auf dem Mega8 verf�gbar
  //Test auf Widerstand
    ADC_PORT = TXD_VAL;
    ADC_DDR = LoADC | TXD_MSK;	//Low-Pin fest auf Masse
    R_DDR = HiPinRL;		//High-Pin �ber R_L auf Plus
    R_PORT = HiPinRL;
    adc.lp1 = W5msReadADC(LowPin);			// low-Spannung unter Last
    adc.hp1 = ReadADC(HighPin) - adc.lp1;	// Spannung am Widerstand RX mit R_L
    R_DDR = HiPinRH;		//High-Pin �ber R_H auf Plus
    R_PORT = HiPinRH;
    adc.hp2 = W5msReadADC(HighPin);			// Spannung am Widerstand RX mit R_H

    //Messung der Spannungsdifferenz zwischen dem Pluspol von R_L und Vcc
    ADC_DDR = HiADC | TXD_MSK;	//High-Pin auf Ausgang
    ADC_PORT = HiADC | TXD_VAL;	//High-Pin fest auf Plus
    R_PORT = 0;
    R_DDR = LoPinRL;				//Low-Pin �ber R_L auf Masse
    adc.hp3 = W5msReadADC(HighPin) - adc.lp1;	//U_VCC - Spannungs-Abfall unter RX+R_L Last
		
    if((adc.hp1 < 4400) && (adc.hp2 > 97))
      { //Spannung f�llt bei geringem Teststrom nicht weit genug ab
 #if DebugOut == 3
       lcd_data('F');
 #endif
       goto testend; 
      }
//    if((adc.hp2 + (adc.hp2 / 61)) < adc.hp1)
    if (adc.hp2 < 4972)
      {  //Abfallende Spannung f�llt bei geringerem Teststrom stark ab und es besteht kein "Beinahe-Kurzschluss" => Widerstand
       if (adc.hp1 > 4821)
         { // lieber Messung mit R_H nehmen
          lrx1 = (unsigned long)R_H_VAL * (unsigned long)adc.hp2 / (U_VCC - adc.hp2);
          kflag = 100;
         }
       else
         {
          lrx1 =(unsigned long)R_L_VAL * (unsigned long)adc.hp1 / (adc.hp3 - adc.hp1);
          kflag = 1;
         }
       if((PartFound == PART_DIODE) || (PartFound == PART_NONE) || (PartFound == PART_RESISTOR))
         {
          for (ii=0; ii<NumOfR; ii++)
            { // nach Messung mit umgekehrter Polarit�t suchen
             thisR = &resis[ii];
             if (thisR->rt != TristatePin) continue;
	     // muss die Messung mit umgekehrter Polarit�t sein
             if (thisR->kfl == kflag)
               {
                if ((labs(thisR->rx - lrx1)*10)/ (thisR->rx + lrx1)  > 0)
                  {
 #if DebugOut == 3
                   lcd_data('r');
                   lcd_ziff(LowPin);
                   lcd_ziff(HighPin);
 #endif
                   goto testend; // <20% Abweichung
                  }
               }
             else
               {
                llrx1 = lrx1 / kflag;
                llrx2 = thisR->rx / thisR->kfl;
                if ((labs(llrx1 - llrx2)*10)/ (llrx1 + llrx2)  > 0)
                  {
 #if DebugOut == 3
                   lcd_data('R');
                   lcd_ziff(LowPin);
                   lcd_ziff(HighPin);
 #endif
                   goto testend; // <20% Abweichung
                  }
               }
              PartFound = PART_RESISTOR;
              goto testend;
            } // end for
          // kein gemessenen R mit gleichem Tristate-Pin gefunden, neu
          thisR = &resis[NumOfR];
          thisR->rx = lrx1;
          thisR->kfl = kflag;
      	  thisR->ra = LowPin;
      	  thisR->rb = HighPin;
          thisR->rt = TristatePin;
      	  NumOfR++;
         }
      }
#endif
  testend:
  ADC_DDR = TXD_MSK;		// alle ADC-Pins Input
  ADC_PORT = TXD_VAL;		// alle ADC Ausg�nge auf Ground, keine Pullup
  R_DDR = 0;			// alle Widerstands-Ausg�nge auf Input
  R_PORT = 0;			// alle Widerstands-Ausg�nge auf Ground, keine Pullup
} // end CheckPins()

