int  queuePeek(void);
unsigned char queueIsEmpty(void);
unsigned char queueIsFull(void);
int queueSize(void);
void queueInsert(int data);
int  queueRemoveData(void);
